(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],2:[function(require,module,exports){
"use strict";

var _wampy = require("./wampy.js");
/**
 * Wrapper for browser usage
 * Set window global variable
 **/

window.Wampy = _wampy.Wampy;

},{"./wampy.js":7}],3:[function(require,module,exports){
(function (process){(function (){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isNode = exports.WAMP_MSG_SPEC = exports.WAMP_ERROR_MSG = exports.SUCCESS = exports.E2EE_SERIALIZERS = void 0;
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
var WAMP_MSG_SPEC = {
  HELLO: 1,
  WELCOME: 2,
  ABORT: 3,
  CHALLENGE: 4,
  AUTHENTICATE: 5,
  GOODBYE: 6,
  ERROR: 8,
  PUBLISH: 16,
  PUBLISHED: 17,
  SUBSCRIBE: 32,
  SUBSCRIBED: 33,
  UNSUBSCRIBE: 34,
  UNSUBSCRIBED: 35,
  EVENT: 36,
  CALL: 48,
  CANCEL: 49,
  RESULT: 50,
  REGISTER: 64,
  REGISTERED: 65,
  UNREGISTER: 66,
  UNREGISTERED: 67,
  INVOCATION: 68,
  INTERRUPT: 69,
  YIELD: 70
};
exports.WAMP_MSG_SPEC = WAMP_MSG_SPEC;
var SUCCESS = {
  code: 0,
  error: null
};
exports.SUCCESS = SUCCESS;
var WAMP_ERROR_MSG = {
  SUCCESS: 'Success!',
  URI_ERROR: 'Topic URI doesn\'t meet requirements!',
  NO_BROKER: 'Server doesn\'t provide broker role!',
  NO_CALLBACK_SPEC: 'No required callback function specified!',
  INVALID_PARAM: 'Invalid parameter(s) specified!',
  NO_SERIALIZER_AVAILABLE: 'Server has chosen a serializer, which is not available!',
  NON_EXIST_UNSUBSCRIBE: 'Trying to unsubscribe from non existent subscription!',
  NO_DEALER: 'Server doesn\'t provide dealer role!',
  RPC_ALREADY_REGISTERED: 'RPC already registered!',
  NON_EXIST_RPC_UNREG: 'Received rpc unregistration for non existent rpc!',
  NON_EXIST_RPC_INVOCATION: 'Received invocation for non existent rpc!',
  NON_EXIST_RPC_REQ_ID: 'No RPC calls in action with specified request ID!',
  NO_REALM: 'No realm specified!',
  NO_WS_OR_URL: 'No websocket provided or URL specified is incorrect!',
  NO_CRA_CB_OR_ID: 'No onChallenge callback or authid was provided for authentication!',
  CHALLENGE_EXCEPTION: 'Exception raised during challenge processing',
  PPT_NOT_SUPPORTED: 'Payload Passthru Mode is not supported by the router',
  PPT_INVALID_SCHEME: 'Provided PPT scheme is invalid',
  PPT_SRLZ_INVALID: 'Provided PPT serializer is invalid or not supported',
  PPT_SRLZ_ERR: 'Can not serialize/deserialize payload',
  PROTOCOL_VIOLATION: 'Protocol violation',
  WAMP_ABORT: 'Router aborted connection',
  WAMP_GENERAL_ERROR: 'Wamp error',
  WEBSOCKET_ERROR: 'Websocket error',
  FEATURE_NOT_SUPPORTED: 'Feature not supported'
};
exports.WAMP_ERROR_MSG = WAMP_ERROR_MSG;
var E2EE_SERIALIZERS = ['cbor'];
exports.E2EE_SERIALIZERS = E2EE_SERIALIZERS;
var isNode = (typeof process === "undefined" ? "undefined" : _typeof(process)) === 'object' && Object.prototype.toString.call(process) === '[object process]';
exports.isNode = isNode;

}).call(this)}).call(this,require('_process'))
},{"_process":1}],4:[function(require,module,exports){
"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WebsocketError = exports.WampError = exports.UriError = exports.UnsubscribeError = exports.UnregisterError = exports.SubscribeError = exports.RegisterError = exports.RPCAlreadyRegisteredError = exports.PublishError = exports.ProtocolViolationError = exports.PPTSerializerInvalidError = exports.PPTSerializationError = exports.PPTNotSupportedError = exports.PPTInvalidSchemeError = exports.NonExistUnsubscribeError = exports.NonExistRPCUnregistrationError = exports.NonExistRPCReqIdError = exports.NoWsOrUrlError = exports.NoSerializerAvailableError = exports.NoRealmError = exports.NoDealerError = exports.NoCallbackError = exports.NoCRACallbackOrIdError = exports.NoBrokerError = exports.InvalidParamError = exports.FeatureNotSupportedError = exports.ChallengeExceptionError = exports.CallError = exports.AbortError = void 0;
var _constants = require("./constants.js");
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }
function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }
function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }
function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }
function _wrapNativeSuper(Class) { var _cache = typeof Map === "function" ? new Map() : undefined; _wrapNativeSuper = function _wrapNativeSuper(Class) { if (Class === null || !_isNativeFunction(Class)) return Class; if (typeof Class !== "function") { throw new TypeError("Super expression must either be null or a function"); } if (typeof _cache !== "undefined") { if (_cache.has(Class)) return _cache.get(Class); _cache.set(Class, Wrapper); } function Wrapper() { return _construct(Class, arguments, _getPrototypeOf(this).constructor); } Wrapper.prototype = Object.create(Class.prototype, { constructor: { value: Wrapper, enumerable: false, writable: true, configurable: true } }); return _setPrototypeOf(Wrapper, Class); }; return _wrapNativeSuper(Class); }
function _construct(Parent, args, Class) { if (_isNativeReflectConstruct()) { _construct = Reflect.construct.bind(); } else { _construct = function _construct(Parent, args, Class) { var a = [null]; a.push.apply(a, args); var Constructor = Function.bind.apply(Parent, a); var instance = new Constructor(); if (Class) _setPrototypeOf(instance, Class.prototype); return instance; }; } return _construct.apply(null, arguments); }
function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }
function _isNativeFunction(fn) { return Function.toString.call(fn).indexOf("[native code]") !== -1; }
function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }
function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }
var UriError = /*#__PURE__*/function (_Error) {
  _inherits(UriError, _Error);
  var _super = _createSuper(UriError);
  function UriError() {
    var _this;
    _classCallCheck(this, UriError);
    _this = _super.call(this, _constants.WAMP_ERROR_MSG.URI_ERROR);
    _this.name = 'UriError';
    _this.code = 1;
    return _this;
  }
  return _createClass(UriError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.UriError = UriError;
var NoBrokerError = /*#__PURE__*/function (_Error2) {
  _inherits(NoBrokerError, _Error2);
  var _super2 = _createSuper(NoBrokerError);
  function NoBrokerError() {
    var _this2;
    _classCallCheck(this, NoBrokerError);
    _this2 = _super2.call(this, _constants.WAMP_ERROR_MSG.NO_BROKER);
    _this2.name = 'NoBrokerError';
    _this2.code = 2;
    return _this2;
  }
  return _createClass(NoBrokerError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.NoBrokerError = NoBrokerError;
var NoCallbackError = /*#__PURE__*/function (_Error3) {
  _inherits(NoCallbackError, _Error3);
  var _super3 = _createSuper(NoCallbackError);
  function NoCallbackError() {
    var _this3;
    _classCallCheck(this, NoCallbackError);
    _this3 = _super3.call(this, _constants.WAMP_ERROR_MSG.NO_CALLBACK_SPEC);
    _this3.name = 'NoCallbackError';
    _this3.code = 3;
    return _this3;
  }
  return _createClass(NoCallbackError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.NoCallbackError = NoCallbackError;
var InvalidParamError = /*#__PURE__*/function (_Error4) {
  _inherits(InvalidParamError, _Error4);
  var _super4 = _createSuper(InvalidParamError);
  function InvalidParamError(parameter) {
    var _this4;
    _classCallCheck(this, InvalidParamError);
    _this4 = _super4.call(this, _constants.WAMP_ERROR_MSG.INVALID_PARAM);
    _this4.name = 'InvalidParamError';
    _this4.code = 4;
    _this4.parameter = parameter;
    return _this4;
  }
  return _createClass(InvalidParamError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.InvalidParamError = InvalidParamError;
var NoSerializerAvailableError = /*#__PURE__*/function (_Error5) {
  _inherits(NoSerializerAvailableError, _Error5);
  var _super5 = _createSuper(NoSerializerAvailableError);
  function NoSerializerAvailableError() {
    var _this5;
    _classCallCheck(this, NoSerializerAvailableError);
    _this5 = _super5.call(this, _constants.WAMP_ERROR_MSG.NO_SERIALIZER_AVAILABLE);
    _this5.name = 'NoSerializerAvailableError';
    _this5.code = 6;
    return _this5;
  }
  return _createClass(NoSerializerAvailableError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.NoSerializerAvailableError = NoSerializerAvailableError;
var NonExistUnsubscribeError = /*#__PURE__*/function (_Error6) {
  _inherits(NonExistUnsubscribeError, _Error6);
  var _super6 = _createSuper(NonExistUnsubscribeError);
  function NonExistUnsubscribeError() {
    var _this6;
    _classCallCheck(this, NonExistUnsubscribeError);
    _this6 = _super6.call(this, _constants.WAMP_ERROR_MSG.NON_EXIST_UNSUBSCRIBE);
    _this6.name = 'NonExistUnsubscribeError';
    _this6.code = 7;
    return _this6;
  }
  return _createClass(NonExistUnsubscribeError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.NonExistUnsubscribeError = NonExistUnsubscribeError;
var NoDealerError = /*#__PURE__*/function (_Error7) {
  _inherits(NoDealerError, _Error7);
  var _super7 = _createSuper(NoDealerError);
  function NoDealerError() {
    var _this7;
    _classCallCheck(this, NoDealerError);
    _this7 = _super7.call(this, _constants.WAMP_ERROR_MSG.NO_DEALER);
    _this7.name = 'NoDealerError';
    _this7.code = 12;
    return _this7;
  }
  return _createClass(NoDealerError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.NoDealerError = NoDealerError;
var RPCAlreadyRegisteredError = /*#__PURE__*/function (_Error8) {
  _inherits(RPCAlreadyRegisteredError, _Error8);
  var _super8 = _createSuper(RPCAlreadyRegisteredError);
  function RPCAlreadyRegisteredError() {
    var _this8;
    _classCallCheck(this, RPCAlreadyRegisteredError);
    _this8 = _super8.call(this, _constants.WAMP_ERROR_MSG.RPC_ALREADY_REGISTERED);
    _this8.name = 'RPCAlreadyRegisteredError';
    _this8.code = 15;
    return _this8;
  }
  return _createClass(RPCAlreadyRegisteredError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.RPCAlreadyRegisteredError = RPCAlreadyRegisteredError;
var NonExistRPCUnregistrationError = /*#__PURE__*/function (_Error9) {
  _inherits(NonExistRPCUnregistrationError, _Error9);
  var _super9 = _createSuper(NonExistRPCUnregistrationError);
  function NonExistRPCUnregistrationError() {
    var _this9;
    _classCallCheck(this, NonExistRPCUnregistrationError);
    _this9 = _super9.call(this, _constants.WAMP_ERROR_MSG.NON_EXIST_RPC_UNREG);
    _this9.name = 'NonExistRPCUnregistrationError';
    _this9.code = 17;
    return _this9;
  }
  return _createClass(NonExistRPCUnregistrationError);
}( /*#__PURE__*/_wrapNativeSuper(Error)); // Not being used at the moment, but left commented here in case we need it
// export class NonExistRPCInvocationError extends Error {
//     constructor () {
//         super(WAMP_ERROR_MSG.NON_EXIST_RPC_INVOCATION);
//         this.name = 'NonExistRPCInvocationError';
//         this.code = 19;
//     }
// }
exports.NonExistRPCUnregistrationError = NonExistRPCUnregistrationError;
var NonExistRPCReqIdError = /*#__PURE__*/function (_Error10) {
  _inherits(NonExistRPCReqIdError, _Error10);
  var _super10 = _createSuper(NonExistRPCReqIdError);
  function NonExistRPCReqIdError() {
    var _this10;
    _classCallCheck(this, NonExistRPCReqIdError);
    _this10 = _super10.call(this, _constants.WAMP_ERROR_MSG.NON_EXIST_RPC_REQ_ID);
    _this10.name = 'NonExistRPCReqIdError';
    _this10.code = 20;
    return _this10;
  }
  return _createClass(NonExistRPCReqIdError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.NonExistRPCReqIdError = NonExistRPCReqIdError;
var NoRealmError = /*#__PURE__*/function (_Error11) {
  _inherits(NoRealmError, _Error11);
  var _super11 = _createSuper(NoRealmError);
  function NoRealmError() {
    var _this11;
    _classCallCheck(this, NoRealmError);
    _this11 = _super11.call(this, _constants.WAMP_ERROR_MSG.NO_REALM);
    _this11.name = 'NoRealmError';
    _this11.code = 21;
    return _this11;
  }
  return _createClass(NoRealmError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.NoRealmError = NoRealmError;
var NoWsOrUrlError = /*#__PURE__*/function (_Error12) {
  _inherits(NoWsOrUrlError, _Error12);
  var _super12 = _createSuper(NoWsOrUrlError);
  function NoWsOrUrlError() {
    var _this12;
    _classCallCheck(this, NoWsOrUrlError);
    _this12 = _super12.call(this, _constants.WAMP_ERROR_MSG.NO_WS_OR_URL);
    _this12.name = 'NoWsOrUrlError';
    _this12.code = 22;
    return _this12;
  }
  return _createClass(NoWsOrUrlError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.NoWsOrUrlError = NoWsOrUrlError;
var NoCRACallbackOrIdError = /*#__PURE__*/function (_Error13) {
  _inherits(NoCRACallbackOrIdError, _Error13);
  var _super13 = _createSuper(NoCRACallbackOrIdError);
  function NoCRACallbackOrIdError() {
    var _this13;
    _classCallCheck(this, NoCRACallbackOrIdError);
    _this13 = _super13.call(this, _constants.WAMP_ERROR_MSG.NO_CRA_CB_OR_ID);
    _this13.name = 'NoCRACallbackOrIdError';
    _this13.code = 23;
    _this13.errorUri = 'wamp.error.cannot_authenticate';
    return _this13;
  }
  return _createClass(NoCRACallbackOrIdError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.NoCRACallbackOrIdError = NoCRACallbackOrIdError;
var ChallengeExceptionError = /*#__PURE__*/function (_Error14) {
  _inherits(ChallengeExceptionError, _Error14);
  var _super14 = _createSuper(ChallengeExceptionError);
  function ChallengeExceptionError() {
    var _this14;
    _classCallCheck(this, ChallengeExceptionError);
    _this14 = _super14.call(this, _constants.WAMP_ERROR_MSG.CHALLENGE_EXCEPTION);
    _this14.name = 'ChallengeExceptionError';
    _this14.code = 24;
    _this14.errorUri = 'wamp.error.cannot_authenticate';
    return _this14;
  }
  return _createClass(ChallengeExceptionError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.ChallengeExceptionError = ChallengeExceptionError;
var PPTNotSupportedError = /*#__PURE__*/function (_Error15) {
  _inherits(PPTNotSupportedError, _Error15);
  var _super15 = _createSuper(PPTNotSupportedError);
  function PPTNotSupportedError() {
    var _this15;
    _classCallCheck(this, PPTNotSupportedError);
    _this15 = _super15.call(this, _constants.WAMP_ERROR_MSG.PPT_NOT_SUPPORTED);
    _this15.name = 'PPTNotSupportedError';
    _this15.code = 25;
    return _this15;
  }
  return _createClass(PPTNotSupportedError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.PPTNotSupportedError = PPTNotSupportedError;
var PPTInvalidSchemeError = /*#__PURE__*/function (_Error16) {
  _inherits(PPTInvalidSchemeError, _Error16);
  var _super16 = _createSuper(PPTInvalidSchemeError);
  function PPTInvalidSchemeError() {
    var _this16;
    _classCallCheck(this, PPTInvalidSchemeError);
    _this16 = _super16.call(this, _constants.WAMP_ERROR_MSG.PPT_INVALID_SCHEME);
    _this16.name = 'PPTInvalidSchemeError';
    _this16.code = 26;
    return _this16;
  }
  return _createClass(PPTInvalidSchemeError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.PPTInvalidSchemeError = PPTInvalidSchemeError;
var PPTSerializerInvalidError = /*#__PURE__*/function (_Error17) {
  _inherits(PPTSerializerInvalidError, _Error17);
  var _super17 = _createSuper(PPTSerializerInvalidError);
  function PPTSerializerInvalidError() {
    var _this17;
    _classCallCheck(this, PPTSerializerInvalidError);
    _this17 = _super17.call(this, _constants.WAMP_ERROR_MSG.PPT_SRLZ_INVALID);
    _this17.name = 'PPTSerializerInvalidError';
    _this17.code = 27;
    return _this17;
  }
  return _createClass(PPTSerializerInvalidError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.PPTSerializerInvalidError = PPTSerializerInvalidError;
var PPTSerializationError = /*#__PURE__*/function (_Error18) {
  _inherits(PPTSerializationError, _Error18);
  var _super18 = _createSuper(PPTSerializationError);
  function PPTSerializationError() {
    var _this18;
    _classCallCheck(this, PPTSerializationError);
    _this18 = _super18.call(this, _constants.WAMP_ERROR_MSG.PPT_SRLZ_ERR);
    _this18.name = 'PPTSerializationError';
    _this18.code = 28;
    return _this18;
  }
  return _createClass(PPTSerializationError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.PPTSerializationError = PPTSerializationError;
var ProtocolViolationError = /*#__PURE__*/function (_Error19) {
  _inherits(ProtocolViolationError, _Error19);
  var _super19 = _createSuper(ProtocolViolationError);
  function ProtocolViolationError(errorUri, details) {
    var _this19;
    _classCallCheck(this, ProtocolViolationError);
    _this19 = _super19.call(this, details || _constants.WAMP_ERROR_MSG.PROTOCOL_VIOLATION);
    _this19.name = 'ProtocolViolationError';
    _this19.code = 29;
    _this19.errorUri = errorUri;
    return _this19;
  }
  return _createClass(ProtocolViolationError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.ProtocolViolationError = ProtocolViolationError;
var AbortError = /*#__PURE__*/function (_Error20) {
  _inherits(AbortError, _Error20);
  var _super20 = _createSuper(AbortError);
  function AbortError(_ref) {
    var _this20;
    var error = _ref.error,
      details = _ref.details;
    _classCallCheck(this, AbortError);
    _this20 = _super20.call(this, _constants.WAMP_ERROR_MSG.WAMP_ABORT);
    _this20.name = 'AbortedError';
    _this20.code = 30;
    _this20.errorUri = error;
    _this20.details = details;
    return _this20;
  }
  return _createClass(AbortError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.AbortError = AbortError;
var WampError = /*#__PURE__*/function (_Error21) {
  _inherits(WampError, _Error21);
  var _super21 = _createSuper(WampError);
  function WampError(_ref2) {
    var _this21;
    var error = _ref2.error,
      details = _ref2.details,
      argsList = _ref2.argsList,
      argsDict = _ref2.argsDict;
    _classCallCheck(this, WampError);
    _this21 = _super21.call(this, _constants.WAMP_ERROR_MSG.WAMP_GENERAL_ERROR);
    _this21.name = 'WampError';
    _this21.code = 31;
    _this21.errorUri = error;
    _this21.details = details;
    _this21.argsList = argsList;
    _this21.argsDict = argsDict;
    return _this21;
  }
  return _createClass(WampError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.WampError = WampError;
var SubscribeError = /*#__PURE__*/function (_WampError) {
  _inherits(SubscribeError, _WampError);
  var _super22 = _createSuper(SubscribeError);
  function SubscribeError(_ref3) {
    var _this22;
    var error = _ref3.error,
      details = _ref3.details,
      argsList = _ref3.argsList,
      argsDict = _ref3.argsDict;
    _classCallCheck(this, SubscribeError);
    _this22 = _super22.call(this, {
      error: error,
      details: details,
      argsList: argsList,
      argsDict: argsDict
    });
    _this22.name = 'SubscribeError';
    _this22.code = 32;
    return _this22;
  }
  return _createClass(SubscribeError);
}(WampError);
exports.SubscribeError = SubscribeError;
var UnsubscribeError = /*#__PURE__*/function (_WampError2) {
  _inherits(UnsubscribeError, _WampError2);
  var _super23 = _createSuper(UnsubscribeError);
  function UnsubscribeError(_ref4) {
    var _this23;
    var error = _ref4.error,
      details = _ref4.details,
      argsList = _ref4.argsList,
      argsDict = _ref4.argsDict;
    _classCallCheck(this, UnsubscribeError);
    _this23 = _super23.call(this, {
      error: error,
      details: details,
      argsList: argsList,
      argsDict: argsDict
    });
    _this23.name = 'UnsubscribeError';
    _this23.code = 33;
    return _this23;
  }
  return _createClass(UnsubscribeError);
}(WampError);
exports.UnsubscribeError = UnsubscribeError;
var PublishError = /*#__PURE__*/function (_WampError3) {
  _inherits(PublishError, _WampError3);
  var _super24 = _createSuper(PublishError);
  function PublishError(_ref5) {
    var _this24;
    var error = _ref5.error,
      details = _ref5.details,
      argsList = _ref5.argsList,
      argsDict = _ref5.argsDict;
    _classCallCheck(this, PublishError);
    _this24 = _super24.call(this, {
      error: error,
      details: details,
      argsList: argsList,
      argsDict: argsDict
    });
    _this24.name = 'PublishError';
    _this24.code = 34;
    return _this24;
  }
  return _createClass(PublishError);
}(WampError);
exports.PublishError = PublishError;
var RegisterError = /*#__PURE__*/function (_WampError4) {
  _inherits(RegisterError, _WampError4);
  var _super25 = _createSuper(RegisterError);
  function RegisterError(_ref6) {
    var _this25;
    var error = _ref6.error,
      details = _ref6.details,
      argsList = _ref6.argsList,
      argsDict = _ref6.argsDict;
    _classCallCheck(this, RegisterError);
    _this25 = _super25.call(this, {
      error: error,
      details: details,
      argsList: argsList,
      argsDict: argsDict
    });
    _this25.name = 'RegisterError';
    _this25.code = 35;
    return _this25;
  }
  return _createClass(RegisterError);
}(WampError);
exports.RegisterError = RegisterError;
var UnregisterError = /*#__PURE__*/function (_WampError5) {
  _inherits(UnregisterError, _WampError5);
  var _super26 = _createSuper(UnregisterError);
  function UnregisterError(_ref7) {
    var _this26;
    var error = _ref7.error,
      details = _ref7.details,
      argsList = _ref7.argsList,
      argsDict = _ref7.argsDict;
    _classCallCheck(this, UnregisterError);
    _this26 = _super26.call(this, {
      error: error,
      details: details,
      argsList: argsList,
      argsDict: argsDict
    });
    _this26.name = 'UnregisterError';
    _this26.code = 36;
    return _this26;
  }
  return _createClass(UnregisterError);
}(WampError);
exports.UnregisterError = UnregisterError;
var CallError = /*#__PURE__*/function (_WampError6) {
  _inherits(CallError, _WampError6);
  var _super27 = _createSuper(CallError);
  function CallError(_ref8) {
    var _this27;
    var error = _ref8.error,
      details = _ref8.details,
      argsList = _ref8.argsList,
      argsDict = _ref8.argsDict;
    _classCallCheck(this, CallError);
    _this27 = _super27.call(this, {
      error: error,
      details: details,
      argsList: argsList,
      argsDict: argsDict
    });
    _this27.name = 'CallError';
    _this27.code = 37;
    return _this27;
  }
  return _createClass(CallError);
}(WampError);
exports.CallError = CallError;
var WebsocketError = /*#__PURE__*/function (_Error22) {
  _inherits(WebsocketError, _Error22);
  var _super28 = _createSuper(WebsocketError);
  function WebsocketError(error) {
    var _this28;
    _classCallCheck(this, WebsocketError);
    _this28 = _super28.call(this, _constants.WAMP_ERROR_MSG.WEBSOCKET_ERROR);
    _this28.name = 'WebsocketError';
    _this28.code = 38;
    _this28.error = error;
    return _this28;
  }
  return _createClass(WebsocketError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.WebsocketError = WebsocketError;
var FeatureNotSupportedError = /*#__PURE__*/function (_Error23) {
  _inherits(FeatureNotSupportedError, _Error23);
  var _super29 = _createSuper(FeatureNotSupportedError);
  function FeatureNotSupportedError(role, feature) {
    var _this29;
    _classCallCheck(this, FeatureNotSupportedError);
    _this29 = _super29.call(this, _constants.WAMP_ERROR_MSG.FEATURE_NOT_SUPPORTED);
    _this29.name = 'FeatureNotSupportedError';
    _this29.code = 39;
    _this29.role = role;
    _this29.feature = feature;
    return _this29;
  }
  return _createClass(FeatureNotSupportedError);
}( /*#__PURE__*/_wrapNativeSuper(Error));
exports.FeatureNotSupportedError = FeatureNotSupportedError;

},{"./constants.js":3}],5:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.JsonSerializer = void 0;
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var JsonSerializer = /*#__PURE__*/function () {
  function JsonSerializer() {
    _classCallCheck(this, JsonSerializer);
    this.protocol = 'json';
    this.isBinary = false;
  }
  _createClass(JsonSerializer, [{
    key: "encode",
    value: function encode(data) {
      return JSON.stringify(data);
    }
  }, {
    key: "decode",
    value: function decode(data) {
      return JSON.parse(data);
    }
  }]);
  return JsonSerializer;
}();
exports.JsonSerializer = JsonSerializer;

},{}],6:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getNewPromise = getNewPromise;
exports.getWebSocket = getWebSocket;
var _constants = require("./constants.js");
function isWebSocketSchemeSpecified(url) {
  return /^ws(s)?:\/\//.test(url);
}
function getServerUrlForNode(url) {
  return isWebSocketSchemeSpecified(url) ? url : null;
}
function getServerUrlForBrowser(url) {
  if (isWebSocketSchemeSpecified(url)) {
    return url;
  }
  var isSecureProtocol = window.location.protocol === 'https:';
  var scheme = isSecureProtocol ? 'wss://' : 'ws://';
  var port = window.location.port ? ":".concat(window.location.port) : '';
  if (!url) {
    return "".concat(scheme).concat(window.location.hostname).concat(port, "/ws");
  }
  if (url.startsWith('/')) {
    // just path on current server
    return "".concat(scheme).concat(window.location.hostname).concat(port).concat(url);
  }

  // assuming just domain + path
  return "".concat(scheme).concat(url);
}

/** Get a WebSocket object from the browsers's window global variable
 *
 * @param {string} parsedUrl The server URL
 * @param {string[]} protocols The WebSocket protocols
 *
 * @returns {Object} A WebSocket Object, or null if none is found
 */
function getWebSocketFromWindowObject(parsedUrl, protocols) {
  var _window, _window2;
  if ((_window = window) !== null && _window !== void 0 && _window.WebSocket) {
    // Chrome, MSIE, newer Firefox
    return new window.WebSocket(parsedUrl, protocols);
  } else if ((_window2 = window) !== null && _window2 !== void 0 && _window2.MozWebSocket) {
    // older versions of Firefox
    return new window.MozWebSocket(parsedUrl, protocols);
  }
  return null;
}

/** Get a WebSocket object according to the user's current environment
 *
 * @param {Object} configObject A configuration object containing multiple properties
 * @param {string} configObject.url The WebSocket URL
 * @param {string[]} configObject.protocols The WebSocket protocols
 * @param {Object} configObject.options An options hash-table
 * @param {WebSocket} configObject.options.ws A user-provided WebSocket class
 * @param {Object} configObject.options.additionalHeaders User provided extra HTTP headers for Node.js
 * @param {Object} configObject.options.wsRequestOptions User provided WS Client Config Options for Node.js
 * @param {boolean} configObject.isBrowserMock A flag indicating if the environment is a simulated browser
 * environment inside Node.js, such as jsdom.
 *
 * @returns {Object} a WebSocket Object, or null if none is found
 */
function getWebSocket() {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
    url = _ref.url,
    protocols = _ref.protocols,
    options = _ref.options,
    isBrowserMock = _ref.isBrowserMock;
  var _ref2 = options || {},
    ws = _ref2.ws,
    additionalHeaders = _ref2.additionalHeaders,
    wsRequestOptions = _ref2.wsRequestOptions;
  var isActualNode = _constants.isNode && !isBrowserMock;
  if (!ws && isActualNode) {
    return null;
  }
  var parsedUrl = isActualNode ? getServerUrlForNode(url) : getServerUrlForBrowser(url);
  if (!parsedUrl) {
    return null;
  }
  if (ws) {
    // User-provided WebSocket class
    return new ws(parsedUrl, protocols, null, additionalHeaders, wsRequestOptions);
  }
  return getWebSocketFromWindowObject(parsedUrl, protocols);
}
function getNewPromise() {
  var promise = {};
  promise.promise = new Promise(function (resolve, reject) {
    promise.onSuccess = resolve;
    promise.onError = reject;
  });
  return promise;
}

},{"./constants.js":3}],7:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = exports.Wampy = exports.Errors = void 0;
var _constants = require("./constants.js");
var Errors = _interopRequireWildcard(require("./errors.js"));
exports.Errors = Errors;
var _utils = require("./utils.js");
var _JsonSerializer = require("./serializers/JsonSerializer.js");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"]; if (null != _i) { var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1; try { if (_x = (_i = _i.call(arr)).next, 0 === i) { if (Object(_i) !== _i) return; _n = !1; } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0) { ; } } catch (err) { _d = !0, _e = err; } finally { try { if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return; } finally { if (_d) throw _e; } } return _arr; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
var jsonSerializer = new _JsonSerializer.JsonSerializer();

/**
 * WAMP Client Class
 */
var Wampy = /*#__PURE__*/function () {
  /**
   * Wampy constructor
   * @param {string} [url]
   * @param {Object} [options]
   */
  function Wampy(url, options) {
    _classCallCheck(this, Wampy);
    /**
     * Wampy version
     * @type {string}
     * @private
     */
    this.version = 'v7.0.2';

    /**
     * WS Url
     * @type {string}
     * @private
     */
    this._url = typeof url === 'string' ? url : null;

    /**
     * WS protocols
     * @type {Array}
     * @private
     */
    this._protocols = ['wamp.2.json'];

    /**
     * WAMP features, supported by Wampy
     * @type {object}
     * @private
     */
    this._wamp_features = {
      agent: 'Wampy.js ' + this.version,
      roles: {
        publisher: {
          features: {
            subscriber_blackwhite_listing: true,
            publisher_exclusion: true,
            publisher_identification: true,
            payload_passthru_mode: true
          }
        },
        subscriber: {
          features: {
            pattern_based_subscription: true,
            publication_trustlevels: true,
            publisher_identification: true,
            payload_passthru_mode: true
          }
        },
        caller: {
          features: {
            caller_identification: true,
            progressive_call_results: true,
            call_canceling: true,
            call_timeout: true,
            payload_passthru_mode: true
          }
        },
        callee: {
          features: {
            caller_identification: true,
            call_trustlevels: true,
            pattern_based_registration: true,
            shared_registration: true,
            payload_passthru_mode: true
          }
        }
      }
    };

    /**
     * Internal cache for object lifetime
     * @type {Object}
     * @private
     */
    this._cache = {
      /**
       * WAMP Session ID
       * @type {string|null}
       */
      sessionId: null,
      /**
       * WAMP Session scope requests ID
       * @type {int}
       */
      reqId: 0,
      /**
       * Server WAMP roles and features
       */
      server_wamp_features: {
        roles: {}
      },
      /**
       * Are we in state of saying goodbye
       * @type {boolean}
       */
      isSayingGoodbye: false,
      /**
       * Status of last operation
       */
      opStatus: {
        /**
         * Int code of last operation
         * @type {int}
         */
        code: 0,
        /**
         * Error of last operation (if not was successful)
         * @type {Error}
         */
        error: null,
        /**
         * Request ID of last successfully sent operation
         * @type {int}
         */
        reqId: 0
      },
      /**
       * Timer for reconnection
       * @type {int|null}
       */
      timer: null,
      /**
       * Reconnection attempts
       * @type {number}
       */
      reconnectingAttempts: 0,
      /**
       * Promise for onConnect
       */
      connectPromise: null,
      /**
       * Promise for onClose
       */
      closePromise: null
    };

    /**
     * WebSocket object
     * @type {WebSocket}
     * @private
     */
    this._ws = null;

    /**
     * Internal queue for websocket requests, for case of disconnect
     * @type {Array}
     * @private
     */
    this._wsQueue = [];

    /**
     * Internal queue for wamp requests
     * @type {object}
     * @private
     */
    this._requests = {};

    /**
     * Stored RPC
     * @type {object}
     * @private
     */
    this._calls = {};

    /**
     * Stored Pub/Subs to access by ID
     * @type {Map}
     * @private
     */
    this._subscriptionsById = new Map();

    /**
     * Stored Pub/Subs to access by Key
     * @type {Map}
     * @private
     */
    this._subscriptionsByKey = new Map();

    /**
     * Stored RPC Registrations
     * @type {object}
     * @private
     */
    this._rpcRegs = {};

    /**
     * Stored RPC names
     * @type {Set}
     * @private
     */
    this._rpcNames = new Set();

    /**
     * Options hash-table
     * @type {Object}
     * @private
     */
    this._options = {
      /**
       * Logging
       * @type {boolean}
       */
      debug: false,
      /**
       * Logger
       * @type {function}
       */
      logger: null,
      /**
       * Reconnecting flag
       * @type {boolean}
       */
      autoReconnect: true,
      /**
       * Reconnecting interval (in ms)
       * @type {number}
       */
      reconnectInterval: 2 * 1000,
      /**
       * Maximum reconnection retries
       * @type {number}
       */
      maxRetries: 25,
      /**
       * WAMP Realm to join
       * @type {string|null}
       */
      realm: null,
      /**
       * Custom attributes to send to router on hello
       * @type {object}
       */
      helloCustomDetails: null,
      /**
       * Validation of the topic URI structure
       * @type {string} - strict or loose
       */
      uriValidation: 'strict',
      /**
       * Authentication id to use in challenge
       * @type {string|null}
       */
      authid: null,
      /**
       * Supported authentication methods
       * @type {array}
       */
      authmethods: [],
      /**
       * Additional authentication options (used in WAMP CryptoSign for example)
       * @type {object}
       */
      authextra: {},
      /**
       * Authentication helpers for processing different authmethods challenge flows
       * @type {object}
       */
      authPlugins: {},
      /**
       * Mode of authorization flow
       * Possible values: manual | auto
       * @type {string}
       */
      authMode: 'manual',
      /**
       * onChallenge callback
       * @type {function}
       */
      onChallenge: null,
      /**
       * onClose callback
       * @type {function}
       */
      onClose: null,
      /**
       * onError callback
       * @type {function}
       */
      onError: null,
      /**
       * onReconnect callback
       * @type {function}
       */
      onReconnect: null,
      /**
       * onReconnectSuccess callback
       * @type {function}
       */
      onReconnectSuccess: null,
      /**
       * User provided WebSocket class
       * @type {function}
       */
      ws: null,
      /**
       * User provided additional HTTP headers (for use in Node.js environment)
       * @type {object}
       */
      additionalHeaders: null,
      /**
       * User provided WS Client Config Options (for use in Node.js environment)
       * @type {object}
       */
      wsRequestOptions: null,
      /**
       * User provided Serializer class
       * @type {object}
       */
      serializer: jsonSerializer,
      /**
       * User provided Serializers for Payload Passthru Mode
       * @type {object}
       */
      payloadSerializers: {
        json: jsonSerializer
      }
    };
    if (this._isPlainObject(options)) {
      this._options = _objectSpread(_objectSpread({}, this._options), options);
    } else if (this._isPlainObject(url)) {
      this._options = _objectSpread(_objectSpread({}, this._options), url);
    }
  }

  /* Internal utils methods */
  /**
   * Internal logger
   * @private
   */
  _createClass(Wampy, [{
    key: "_log",
    value: function _log() {
      if (!this._options.debug) {
        return;
      }
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      if (this._options.logger) {
        return this._options.logger(args);
      }
      return console.log('[wampy]', args);
    }

    /**
     * Get the new unique request id
     * @returns {number}
     * @private
     */
  }, {
    key: "_getReqId",
    value: function _getReqId() {
      return ++this._cache.reqId;
    }

    /**
     * Check if input is an object literal
     * @param input
     * @returns {boolean}
     * @private
     */
  }, {
    key: "_isPlainObject",
    value: function _isPlainObject(input) {
      var constructor = input === null || input === void 0 ? void 0 : input.constructor;
      var prototype = constructor === null || constructor === void 0 ? void 0 : constructor.prototype;
      return Object.prototype.toString.call(input) === '[object Object]' // checks for primitives, null, Arrays, DOM, etc.
      && typeof constructor === 'function' // checks for modified constructors
      && Object.prototype.toString.call(prototype) === '[object Object]' // checks for modified prototypes
      && Object.hasOwnProperty.call(prototype, 'isPrototypeOf'); // checks for missing object-specific property
    }

    /**
     * Set websocket protocol based on options
     * @private
     */
  }, {
    key: "_setWsProtocols",
    value: function _setWsProtocols() {
      this._protocols = ['wamp.2.' + this._options.serializer.protocol];
      // FIXME: Temporary commented out due to bug in Nexus
      // if (!(this._options.serializer instanceof JsonSerializer)) {
      //     this._protocols.unshift('wamp.2.' + this._options.serializer.protocol);
      // }
    }

    /**
     * Fill instance operation status
     * @param {Error} err
     * @private
     */
  }, {
    key: "_fillOpStatusByError",
    value: function _fillOpStatusByError(err) {
      this._cache.opStatus = {
        code: err.code,
        error: err,
        reqId: 0
      };
    }

    /**
     * Prerequisite checks for any wampy api call
     * @param {object} topicType { topic: URI, patternBased: true|false, allowWAMP: true|false }
     * @param {string} role
     * @returns {boolean}
     * @private
     */
  }, {
    key: "_preReqChecks",
    value: function _preReqChecks(topicType, role) {
      if (this._cache.sessionId && !this._cache.server_wamp_features.roles[role]) {
        var errorsByRole = {
          dealer: new Errors.NoDealerError(),
          broker: new Errors.NoBrokerError()
        };
        this._fillOpStatusByError(errorsByRole[role]);
        return false;
      }
      if (topicType && !this._validateURI(topicType.topic, topicType.patternBased, topicType.allowWAMP)) {
        this._fillOpStatusByError(new Errors.UriError());
        return false;
      }
      return true;
    }

    /**
     * Check for specified feature in a role of connected WAMP Router
     * @param {string} role
     * @param {string} feature
     * @returns {boolean}
     * @private
     */
  }, {
    key: "_checkRouterFeature",
    value: function _checkRouterFeature(role, feature) {
      if (this._cache.server_wamp_features.roles[role].features[feature] !== true) {
        this._fillOpStatusByError(new Errors.FeatureNotSupportedError(role, feature));
        return false;
      }
      return true;
    }

    /**
     * Check for PPT mode options correctness
     * @param {string} role WAMP Router Role to check support
     * @param {object} options
     * @returns {boolean}
     * @private
     */
  }, {
    key: "_checkPPTOptions",
    value: function _checkPPTOptions(role, options) {
      if (!this._checkRouterFeature(role, 'payload_passthru_mode')) {
        this._fillOpStatusByError(new Errors.PPTNotSupportedError());
        return false;
      }
      if (options.ppt_scheme.search(/^(wamp$|mqtt$|x_)/) < 0) {
        this._fillOpStatusByError(new Errors.PPTInvalidSchemeError());
        return false;
      }
      if (options.ppt_scheme === 'wamp' && !_constants.E2EE_SERIALIZERS.includes(options.ppt_serializer)) {
        this._fillOpStatusByError(new Errors.PPTSerializerInvalidError());
        return false;
      }
      return true;
    }

    /**
     * Validate uri
     * @param {string} uri
     * @param {boolean} isPatternBased
     * @param {boolean} isWampAllowed
     * @returns {boolean}
     * @private
     */
  }, {
    key: "_validateURI",
    value: function _validateURI(uri, isPatternBased, isWampAllowed) {
      var isStrictValidation = this._options.uriValidation === 'strict';
      var isLooseValidation = this._options.uriValidation === 'loose';
      var isValidationTypeUnknown = !isStrictValidation && !isLooseValidation;
      if (isValidationTypeUnknown || uri.startsWith('wamp.') && !isWampAllowed) {
        return false;
      }
      var reBase, rePattern;
      if (isStrictValidation) {
        reBase = /^(\w+\.)*(\w+)$/;
        rePattern = /^(\w+\.{1,2})*(\w+)$/;
      } else if (isLooseValidation) {
        reBase = /^([^\s.#]+\.)*([^\s.#]+)$/;
        rePattern = /^([^\s.#]+\.{1,2})*([^\s.#]+)$/;
      }
      return (isPatternBased ? rePattern : reBase).test(uri);
    }

    /**
     * Prepares PPT/E2EE payload for adding to WAMP message
     * @param {string|number|Array|object} payload
     * @param {Object} options
     * @returns {Object}
     * @private
     */
  }, {
    key: "_packPPTPayload",
    value: function _packPPTPayload(payload, options) {
      var isArgsListInvalid = (payload === null || payload === void 0 ? void 0 : payload.argsList) && !Array.isArray(payload.argsList);
      var isArgsDictInvalid = (payload === null || payload === void 0 ? void 0 : payload.argsDict) && !this._isPlainObject(payload.argsDict);
      if (isArgsListInvalid || isArgsDictInvalid) {
        var invalidParameter = isArgsListInvalid ? payload.argsList : payload.argsDict;
        this._fillOpStatusByError(new Errors.InvalidParamError(invalidParameter));
        return {
          err: true,
          payloadItems: []
        };
      }
      var isPayloadAnObject = this._isPlainObject(payload);
      var argsList = payload.argsList,
        argsDict = payload.argsDict;
      var args, kwargs;
      if (isPayloadAnObject && !argsList && !argsDict) {
        kwargs = payload;
      } else if (isPayloadAnObject) {
        args = argsList;
        kwargs = argsDict;
      } else if (Array.isArray(payload)) {
        args = payload;
      } else {
        // assume it's a single value
        args = [payload];
      }
      var payloadItems = [];
      if (!options.ppt_scheme) {
        if (args) {
          payloadItems.push(args);
        }
        if (kwargs) {
          if (!args) {
            payloadItems.push([]);
          }
          payloadItems.push(kwargs);
        }
        return {
          err: false,
          payloadItems: payloadItems
        };
      }
      var pptPayload = {
        args: args,
        kwargs: kwargs
      };
      var binPayload = pptPayload;

      // Check and handle Payload PassThru Mode
      // @see https://wamp-proto.org/wamp_latest_ietf.html#name-payload-passthru-mode
      if (options.ppt_serializer && options.ppt_serializer !== 'native') {
        var pptSerializer = this._options.payloadSerializers[options.ppt_serializer];
        if (!pptSerializer) {
          this._fillOpStatusByError(new Errors.PPTSerializerInvalidError());
          return {
            err: true,
            payloadItems: payloadItems
          };
        }
        try {
          binPayload = pptSerializer.encode(pptPayload);
        } catch (e) {
          this._fillOpStatusByError(new Errors.PPTSerializationError());
          return {
            err: true,
            payloadItems: payloadItems
          };
        }
      }

      // TODO: implement End-to-End Encryption
      // wamp scheme means Payload End-to-End Encryption
      // @see https://wamp-proto.org/wamp_latest_ietf.html#name-payload-end-to-end-encrypti
      // if (options.ppt_scheme === 'wamp') {
      //
      // }

      payloadItems.push([binPayload]);
      return {
        err: false,
        payloadItems: payloadItems
      };
    }

    /**
     * Unpack PPT/E2EE payload to common
     * @param {string} role
     * @param {Array} pptPayload
     * @param {Object} options
     * @returns {Object}
     * @private
     */
  }, {
    key: "_unpackPPTPayload",
    value: function _unpackPPTPayload(role, pptPayload, options) {
      var decodedPayload;
      if (!this._checkPPTOptions(role, options)) {
        return {
          err: this._cache.opStatus.error
        };
      }

      // TODO: implement End-to-End Encryption
      // wamp scheme means Payload End-to-End Encryption
      // @see https://wamp-proto.org/wamp_latest_ietf.html#name-payload-end-to-end-encrypti
      // if (options.ppt_scheme === 'wamp') {
      //
      // }

      if (options.ppt_serializer && options.ppt_serializer !== 'native') {
        var pptSerializer = this._options.payloadSerializers[options.ppt_serializer];
        if (!pptSerializer) {
          return {
            err: new Errors.PPTSerializerInvalidError()
          };
        }
        try {
          decodedPayload = pptSerializer.decode(pptPayload);
        } catch (e) {
          return {
            err: new Errors.PPTSerializationError()
          };
        }
      } else {
        decodedPayload = pptPayload;
      }
      return {
        err: false,
        args: decodedPayload.args,
        kwargs: decodedPayload.kwargs
      };
    }

    /**
     * Encode WAMP message
     * @param {Array} msg
     * @returns {*}
     * @private
     */
  }, {
    key: "_encode",
    value: function _encode(msg) {
      try {
        return this._options.serializer.encode(msg);
      } catch (e) {
        this._hardClose('wamp.error.protocol_violation', 'Can not encode message', true);
      }
    }

    /**
     * Decode WAMP message
     * @param  msg
     * @returns {Promise}
     * @private
     */
  }, {
    key: "_decode",
    value: function _decode(msg) {
      try {
        return this._options.serializer.decode(msg);
      } catch (e) {
        this._hardClose('wamp.error.protocol_violation', 'Can not decode received message');
      }
    }

    /**
     * Hard close of connection due to protocol violations
     * @param {string} errorUri
     * @param {string} details
     * @param {boolean} [noSend]
     * @private
     */
  }, {
    key: "_hardClose",
    value: function _hardClose(errorUri, details) {
      var noSend = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
      this._log(details);
      // Cleanup outgoing message queue
      this._wsQueue = [];
      if (!noSend) {
        this._send([_constants.WAMP_MSG_SPEC.ABORT, {
          message: details
        }, errorUri]);
      }
      var protocolViolationError = new Errors.ProtocolViolationError(errorUri, details);

      // In case we were just making first connection
      if (this._cache.connectPromise) {
        this._cache.connectPromise.onError(protocolViolationError);
        this._cache.connectPromise = null;
      }
      if (this._options.onError) {
        this._options.onError(protocolViolationError);
      }
      this._ws.close();
    }

    /**
     * Send encoded message to server
     * @param {Array} [msg]
     * @private
     */
  }, {
    key: "_send",
    value: function _send(msg) {
      if (msg) {
        this._wsQueue.push(this._encode(msg));
      }
      if (this._ws && this._ws.readyState === 1 && this._cache.sessionId) {
        while (this._wsQueue.length) {
          this._ws.send(this._wsQueue.shift());
        }
      }
    }

    /**
     * Reset internal state and cache
     * @private
     */
  }, {
    key: "_resetState",
    value: function _resetState() {
      this._wsQueue = [];
      this._subscriptionsById.clear();
      this._subscriptionsByKey.clear();
      this._requests = {};
      this._calls = {};
      this._rpcRegs = {};
      this._rpcNames = new Set();

      // Just keep attrs that are have to be present
      this._cache = {
        reqId: 0,
        reconnectingAttempts: 0,
        opStatus: _constants.SUCCESS,
        closePromise: null,
        connectPromise: null
      };
    }

    /**
     * Initialize internal websocket callbacks
     * @private
     */
  }, {
    key: "_initWsCallbacks",
    value: function _initWsCallbacks() {
      var _this = this;
      this._ws.onopen = function () {
        return _this._wsOnOpen();
      };
      this._ws.onclose = function (event) {
        return _this._wsOnClose(event);
      };
      this._ws.onmessage = function (event) {
        return _this._wsOnMessage(event);
      };
      this._ws.onerror = function (error) {
        return _this._wsOnError(error);
      };
    }

    /**
     * Internal websocket on open callback
     * @private
     */
  }, {
    key: "_wsOnOpen",
    value: function _wsOnOpen() {
      var _this$_ws$protocol, _this$_ws$protocol$sp;
      var _this$_options = this._options,
        helloCustomDetails = _this$_options.helloCustomDetails,
        authmethods = _this$_options.authmethods,
        authid = _this$_options.authid,
        authextra = _this$_options.authextra,
        serializer = _this$_options.serializer,
        onError = _this$_options.onError,
        realm = _this$_options.realm;
      var serverProtocol = (_this$_ws$protocol = this._ws.protocol) === null || _this$_ws$protocol === void 0 ? void 0 : (_this$_ws$protocol$sp = _this$_ws$protocol.split('.')) === null || _this$_ws$protocol$sp === void 0 ? void 0 : _this$_ws$protocol$sp[2];
      var hasServerChosenOurPreferredProtocol = serverProtocol === serializer.protocol;
      this._log("Websocket connected. Server has chosen protocol: \"".concat(serverProtocol, "\""));
      if (!hasServerChosenOurPreferredProtocol) {
        if (serverProtocol === 'json') {
          this._options.serializer = new _JsonSerializer.JsonSerializer();
        } else {
          var noSerializerAvailableError = new Errors.NoSerializerAvailableError();
          this._fillOpStatusByError(noSerializerAvailableError);
          if (this._cache.connectPromise) {
            this._cache.connectPromise.onError(noSerializerAvailableError);
            this._cache.connectPromise = null;
          }
          if (onError) {
            onError(noSerializerAvailableError);
          }
        }
      }
      if (serializer.isBinary) {
        this._ws.binaryType = 'arraybuffer';
      }
      var messageOptions = _objectSpread(_objectSpread(_objectSpread({}, helloCustomDetails), this._wamp_features), authid ? {
        authid: authid,
        authmethods: authmethods,
        authextra: authextra
      } : {});
      var encodedMessage = this._encode([_constants.WAMP_MSG_SPEC.HELLO, realm, messageOptions]);
      if (encodedMessage) {
        // Sending directly 'cause it's a hello message and no sessionId check is needed
        this._ws.send(encodedMessage);
      }
    }

    /**
     * Internal websocket on close callback
     * @param {object} event
     * @private
     */
  }, {
    key: "_wsOnClose",
    value: function _wsOnClose(event) {
      var _this2 = this;
      this._log('websocket disconnected. Info: ', event);

      // Automatic reconnection
      if ((this._cache.sessionId || this._cache.reconnectingAttempts) && this._options.autoReconnect && (this._options.maxRetries === 0 || this._cache.reconnectingAttempts < this._options.maxRetries) && !this._cache.isSayingGoodbye) {
        this._cache.sessionId = null;
        this._cache.timer = setTimeout(function () {
          _this2._wsReconnect();
        }, this._options.reconnectInterval);
      } else {
        // No reconnection needed or reached max retries count
        if (this._options.onClose) {
          this._options.onClose();
        } else if (this._cache.closePromise) {
          this._cache.closePromise.onSuccess();
          this._cache.closePromise = null;
        }
        this._resetState();
        this._ws = null;
      }
    }

    /**
     * Internal websocket on event callback
     * @param {object} event
     * @private
     */
  }, {
    key: "_wsOnMessage",
    value: function () {
      var _wsOnMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(event) {
        var _this3 = this,
          _messageHandlers;
        var data, messageType, messageHandlers, handler, errorURI, needNoSession, needValidSession;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                data = this._decode(event.data);
                this._log('websocket message received: ', data);
                messageType = data[0];
                messageHandlers = (_messageHandlers = {}, _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.WELCOME, function () {
                  return _this3._onWelcomeMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.ABORT, function () {
                  return _this3._onAbortMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.CHALLENGE, function () {
                  return _this3._onChallengeMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.GOODBYE, function () {
                  return _this3._onGoodbyeMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.ERROR, function () {
                  return _this3._onErrorMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.SUBSCRIBED, function () {
                  return _this3._onSubscribedMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.UNSUBSCRIBED, function () {
                  return _this3._onUnsubscribedMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.PUBLISHED, function () {
                  return _this3._onPublishedMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.EVENT, function () {
                  return _this3._onEventMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.RESULT, function () {
                  return _this3._onResultMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.REGISTERED, function () {
                  return _this3._onRegisteredMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.UNREGISTERED, function () {
                  return _this3._onUnregisteredMessage(data);
                }), _defineProperty(_messageHandlers, _constants.WAMP_MSG_SPEC.INVOCATION, function () {
                  return _this3._onInvocationMessage(data);
                }), _messageHandlers);
                handler = messageHandlers[messageType];
                errorURI = 'wamp.error.protocol_violation';
                if (handler) {
                  _context.next = 8;
                  break;
                }
                return _context.abrupt("return", this._hardClose(errorURI, "Received non-compliant WAMP message: \"".concat(messageType, "\"")));
              case 8:
                needNoSession = [_constants.WAMP_MSG_SPEC.WELCOME, _constants.WAMP_MSG_SPEC.CHALLENGE].includes(messageType);
                needValidSession = !needNoSession && messageType !== _constants.WAMP_MSG_SPEC.ABORT;
                if (!(needNoSession && this._cache.sessionId)) {
                  _context.next = 12;
                  break;
                }
                return _context.abrupt("return", this._hardClose(errorURI, "Received message \"".concat(messageType, "\" after session was established")));
              case 12:
                if (!(needValidSession && !this._cache.sessionId)) {
                  _context.next = 14;
                  break;
                }
                return _context.abrupt("return", this._hardClose(errorURI, "Received message \"".concat(messageType, "\" before session was established")));
              case 14:
                _context.next = 16;
                return handler();
              case 16:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
      function _wsOnMessage(_x) {
        return _wsOnMessage2.apply(this, arguments);
      }
      return _wsOnMessage;
    }()
    /**
     * Handles websocket welcome message event
     * WAMP SPEC: [WELCOME, Session|id, Details|dict]
     * @param {Array} [, sessionId, details] - decoded event data
     * @private
     */
  }, {
    key: "_onWelcomeMessage",
    value: function () {
      var _onWelcomeMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2(_ref) {
        var _ref2, sessionId, details;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _ref2 = _slicedToArray(_ref, 3), sessionId = _ref2[1], details = _ref2[2];
                this._cache.sessionId = sessionId;
                this._cache.server_wamp_features = details;
                if (!this._cache.reconnectingAttempts) {
                  _context2.next = 12;
                  break;
                }
                this._cache.reconnectingAttempts = 0;
                if (!this._options.onReconnectSuccess) {
                  _context2.next = 8;
                  break;
                }
                _context2.next = 8;
                return this._options.onReconnectSuccess(details);
              case 8:
                // Renew all previous state
                this._renewSubscriptions();
                this._renewRegistrations();
                _context2.next = 14;
                break;
              case 12:
                // Fire onConnect event on real connection to WAMP server
                this._cache.connectPromise.onSuccess(details);
                this._cache.connectPromise = null;
              case 14:
                // Send local queue if there is something out there
                this._send();
              case 15:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
      function _onWelcomeMessage(_x2) {
        return _onWelcomeMessage2.apply(this, arguments);
      }
      return _onWelcomeMessage;
    }()
    /**
     * Handles websocket abort message event
     * WAMP SPEC: [ABORT, Details|dict, Error|uri]
     * @param {Array} [, details, error] - decoded event data array
     * @private
     */
  }, {
    key: "_onAbortMessage",
    value: function () {
      var _onAbortMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(_ref3) {
        var _ref4, details, error, err;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _ref4 = _slicedToArray(_ref3, 3), details = _ref4[1], error = _ref4[2];
                err = new Errors.AbortError({
                  error: error,
                  details: details
                });
                if (this._cache.connectPromise) {
                  this._cache.connectPromise.onError(err);
                  this._cache.connectPromise = null;
                }
                if (!this._options.onError) {
                  _context3.next = 6;
                  break;
                }
                _context3.next = 6;
                return this._options.onError(err);
              case 6:
                this._ws.close();
              case 7:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
      function _onAbortMessage(_x3) {
        return _onAbortMessage2.apply(this, arguments);
      }
      return _onAbortMessage;
    }()
    /**
     * Handles websocket challenge message event
     * WAMP SPEC: [CHALLENGE, AuthMethod|string, Extra|dict]
     * @param {Array} [, authMethod, extra] - decoded event data array
     * @private
     */
  }, {
    key: "_onChallengeMessage",
    value: function () {
      var _onChallengeMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4(_ref5) {
        var _ref6, authMethod, extra, promise, _this$_options2, authid, authMode, onChallenge, onError, authPlugins, noCRACallbackOrIdError, key, challengeExceptionError;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _ref6 = _slicedToArray(_ref5, 3), authMethod = _ref6[1], extra = _ref6[2];
                _this$_options2 = this._options, authid = _this$_options2.authid, authMode = _this$_options2.authMode, onChallenge = _this$_options2.onChallenge, onError = _this$_options2.onError, authPlugins = _this$_options2.authPlugins;
                if (!(authid && authMode === 'manual' && typeof onChallenge === 'function')) {
                  _context4.next = 6;
                  break;
                }
                promise = new Promise(function (resolve) {
                  resolve(onChallenge(authMethod, extra));
                });
                _context4.next = 17;
                break;
              case 6:
                if (!(authid && authMode === 'auto' && typeof authPlugins[authMethod] === 'function')) {
                  _context4.next = 10;
                  break;
                }
                promise = new Promise(function (resolve) {
                  resolve(authPlugins[authMethod](authMethod, extra));
                });
                _context4.next = 17;
                break;
              case 10:
                noCRACallbackOrIdError = new Errors.NoCRACallbackOrIdError();
                this._fillOpStatusByError(noCRACallbackOrIdError);
                this._ws.send(this._encode([_constants.WAMP_MSG_SPEC.ABORT, {
                  message: noCRACallbackOrIdError.message
                }, 'wamp.error.cannot_authenticate']));
                if (!onError) {
                  _context4.next = 16;
                  break;
                }
                _context4.next = 16;
                return onError(noCRACallbackOrIdError);
              case 16:
                return _context4.abrupt("return", this._ws.close());
              case 17:
                _context4.prev = 17;
                _context4.next = 20;
                return promise;
              case 20:
                key = _context4.sent;
                // Sending directly 'cause it's a challenge msg and no sessionId check is needed
                this._ws.send(this._encode([_constants.WAMP_MSG_SPEC.AUTHENTICATE, key, {}]));
                _context4.next = 33;
                break;
              case 24:
                _context4.prev = 24;
                _context4.t0 = _context4["catch"](17);
                challengeExceptionError = new Errors.ChallengeExceptionError();
                this._fillOpStatusByError(challengeExceptionError);
                this._ws.send(this._encode([_constants.WAMP_MSG_SPEC.ABORT, {
                  message: challengeExceptionError.message
                }, 'wamp.error.cannot_authenticate']));
                if (!onError) {
                  _context4.next = 32;
                  break;
                }
                _context4.next = 32;
                return onError(challengeExceptionError);
              case 32:
                this._ws.close();
              case 33:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this, [[17, 24]]);
      }));
      function _onChallengeMessage(_x4) {
        return _onChallengeMessage2.apply(this, arguments);
      }
      return _onChallengeMessage;
    }()
    /**
     * Handles websocket goodbye message event
     * WAMP SPEC: [GOODBYE, Details|dict, Reason|uri]
     * @private
     */
  }, {
    key: "_onGoodbyeMessage",
    value: function () {
      var _onGoodbyeMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                if (!this._cache.isSayingGoodbye) {
                  // get goodbye, initiated by server
                  this._cache.isSayingGoodbye = true;
                  this._send([_constants.WAMP_MSG_SPEC.GOODBYE, {}, 'wamp.close.goodbye_and_out']);
                }
                this._cache.sessionId = null;
                this._ws.close();
              case 3:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));
      function _onGoodbyeMessage() {
        return _onGoodbyeMessage2.apply(this, arguments);
      }
      return _onGoodbyeMessage;
    }()
    /**
     * Handles websocket error message event
     * WAMP SPEC: [ERROR, REQUEST.Type|int, REQUEST.Request|id, Details|dict,
     *             Error|uri, (Arguments|list, ArgumentsKw|dict)]
     * @param {Array} [, requestType, requestId, details, error, argsList, argsDict] - decoded event data array
     * @private
     */
  }, {
    key: "_onErrorMessage",
    value: function () {
      var _onErrorMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6(_ref7) {
        var _errorsByRequestType;
        var _ref8, requestType, requestId, details, error, argsList, argsDict, errorOptions, errorsByRequestType, currentError, _this$_calls$requestI, _this$_requests$reque, _this$_requests$reque2;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _ref8 = _slicedToArray(_ref7, 7), requestType = _ref8[1], requestId = _ref8[2], details = _ref8[3], error = _ref8[4], argsList = _ref8[5], argsDict = _ref8[6];
                errorOptions = {
                  error: error,
                  details: details,
                  argsList: argsList,
                  argsDict: argsDict
                };
                errorsByRequestType = (_errorsByRequestType = {}, _defineProperty(_errorsByRequestType, _constants.WAMP_MSG_SPEC.SUBSCRIBE, new Errors.SubscribeError(errorOptions)), _defineProperty(_errorsByRequestType, _constants.WAMP_MSG_SPEC.UNSUBSCRIBE, new Errors.UnsubscribeError(errorOptions)), _defineProperty(_errorsByRequestType, _constants.WAMP_MSG_SPEC.PUBLISH, new Errors.PublishError(errorOptions)), _defineProperty(_errorsByRequestType, _constants.WAMP_MSG_SPEC.REGISTER, new Errors.RegisterError(errorOptions)), _defineProperty(_errorsByRequestType, _constants.WAMP_MSG_SPEC.UNREGISTER, new Errors.UnregisterError(errorOptions)), _defineProperty(_errorsByRequestType, _constants.WAMP_MSG_SPEC.CALL, new Errors.CallError(errorOptions)), _errorsByRequestType);
                currentError = errorsByRequestType[requestType];
                if (currentError) {
                  _context6.next = 6;
                  break;
                }
                return _context6.abrupt("return", this._hardClose('wamp.error.protocol_violation', 'Received invalid ERROR message'));
              case 6:
                if (!(requestType === _constants.WAMP_MSG_SPEC.CALL)) {
                  _context6.next = 13;
                  break;
                }
                if (!((_this$_calls$requestI = this._calls[requestId]) !== null && _this$_calls$requestI !== void 0 && _this$_calls$requestI.onError)) {
                  _context6.next = 10;
                  break;
                }
                _context6.next = 10;
                return this._calls[requestId].onError(currentError);
              case 10:
                delete this._calls[requestId];
                _context6.next = 17;
                break;
              case 13:
                if (!((_this$_requests$reque = this._requests[requestId]) !== null && _this$_requests$reque !== void 0 && (_this$_requests$reque2 = _this$_requests$reque.callbacks) !== null && _this$_requests$reque2 !== void 0 && _this$_requests$reque2.onError)) {
                  _context6.next = 16;
                  break;
                }
                _context6.next = 16;
                return this._requests[requestId].callbacks.onError(currentError);
              case 16:
                delete this._requests[requestId];
              case 17:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));
      function _onErrorMessage(_x5) {
        return _onErrorMessage2.apply(this, arguments);
      }
      return _onErrorMessage;
    }()
    /**
     * Handles websocket subscribed message event
     * WAMP SPEC: [SUBSCRIBED, SUBSCRIBE.Request|id, Subscription|id]
     * @param {Array} [, requestId, subscriptionId] - decoded event data Array, with the
     * second and third elements of the Array being the requestId and subscriptionId respectively
     * @private
     */
  }, {
    key: "_onSubscribedMessage",
    value: function () {
      var _onSubscribedMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7(_ref9) {
        var _ref10, requestId, subscriptionId, _this$_requests$reque3, topic, advancedOptions, callbacks, subscription, subscriptionKey;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _ref10 = _slicedToArray(_ref9, 3), requestId = _ref10[1], subscriptionId = _ref10[2];
                if (this._requests[requestId]) {
                  _context7.next = 3;
                  break;
                }
                return _context7.abrupt("return");
              case 3:
                _this$_requests$reque3 = this._requests[requestId], topic = _this$_requests$reque3.topic, advancedOptions = _this$_requests$reque3.advancedOptions, callbacks = _this$_requests$reque3.callbacks;
                subscription = {
                  id: subscriptionId,
                  topic: topic,
                  advancedOptions: advancedOptions,
                  callbacks: [callbacks.onEvent]
                };
                subscriptionKey = this._getSubscriptionKey(topic, advancedOptions);
                this._subscriptionsById.set(subscriptionId, subscription);
                this._subscriptionsByKey.set(subscriptionKey, subscription);
                if (!callbacks.onSuccess) {
                  _context7.next = 11;
                  break;
                }
                _context7.next = 11;
                return callbacks.onSuccess({
                  topic: topic,
                  requestId: requestId,
                  subscriptionId: subscriptionId,
                  subscriptionKey: subscriptionKey
                });
              case 11:
                delete this._requests[requestId];
              case 12:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));
      function _onSubscribedMessage(_x6) {
        return _onSubscribedMessage2.apply(this, arguments);
      }
      return _onSubscribedMessage;
    }()
    /**
     * Handles websocket unsubscribed message event
     * WAMP SPEC: [UNSUBSCRIBED, UNSUBSCRIBE.Request|id]
     * @param {Array} [, requestId] - decoded event data Array, with the
     * second element of the Array being the requestId
     * @private
     */
  }, {
    key: "_onUnsubscribedMessage",
    value: function () {
      var _onUnsubscribedMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee8(_ref11) {
        var _ref12, requestId, _this$_requests$reque4, topic, advancedOptions, callbacks, subscriptionKey, subscriptionId;
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _ref12 = _slicedToArray(_ref11, 2), requestId = _ref12[1];
                if (this._requests[requestId]) {
                  _context8.next = 3;
                  break;
                }
                return _context8.abrupt("return");
              case 3:
                _this$_requests$reque4 = this._requests[requestId], topic = _this$_requests$reque4.topic, advancedOptions = _this$_requests$reque4.advancedOptions, callbacks = _this$_requests$reque4.callbacks;
                subscriptionKey = this._getSubscriptionKey(topic, advancedOptions);
                subscriptionId = this._subscriptionsByKey.get(subscriptionKey).id;
                this._subscriptionsByKey["delete"](subscriptionKey);
                this._subscriptionsById["delete"](subscriptionId);
                if (!callbacks.onSuccess) {
                  _context8.next = 11;
                  break;
                }
                _context8.next = 11;
                return callbacks.onSuccess({
                  topic: topic,
                  requestId: requestId
                });
              case 11:
                delete this._requests[requestId];
              case 12:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this);
      }));
      function _onUnsubscribedMessage(_x7) {
        return _onUnsubscribedMessage2.apply(this, arguments);
      }
      return _onUnsubscribedMessage;
    }()
    /**
     * Handles websocket published message event
     * WAMP SPEC: [PUBLISHED, PUBLISH.Request|id, Publication|id]
     * @param {Array} [, requestId, publicationId] - decoded event data
     * @private
     */
  }, {
    key: "_onPublishedMessage",
    value: function () {
      var _onPublishedMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee9(_ref13) {
        var _ref14, requestId, publicationId, _this$_requests$reque5, topic, callbacks;
        return _regeneratorRuntime().wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _ref14 = _slicedToArray(_ref13, 3), requestId = _ref14[1], publicationId = _ref14[2];
                if (this._requests[requestId]) {
                  _context9.next = 3;
                  break;
                }
                return _context9.abrupt("return");
              case 3:
                _this$_requests$reque5 = this._requests[requestId], topic = _this$_requests$reque5.topic, callbacks = _this$_requests$reque5.callbacks;
                if (!(callbacks !== null && callbacks !== void 0 && callbacks.onSuccess)) {
                  _context9.next = 7;
                  break;
                }
                _context9.next = 7;
                return callbacks.onSuccess({
                  topic: topic,
                  requestId: requestId,
                  publicationId: publicationId
                });
              case 7:
                delete this._requests[requestId];
              case 8:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, this);
      }));
      function _onPublishedMessage(_x8) {
        return _onPublishedMessage2.apply(this, arguments);
      }
      return _onPublishedMessage;
    }()
    /**
     * Handles websocket event message event
     * WAMP SPEC: [EVENT, SUBSCRIBED.Subscription|id, PUBLISHED.Publication|id,
     *            Details|dict, PUBLISH.Arguments|list, PUBLISH.ArgumentKw|dict]
     * @param {Array} [, subscriptionId, publicationId, details, argsList, argsDict] - decoded event data
     * @private
     */
  }, {
    key: "_onEventMessage",
    value: function () {
      var _onEventMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee10(_ref15) {
        var _ref16, subscriptionId, publicationId, details, argsList, argsDict, subscription, args, kwargs, pptPayload, decodedPayload, callbackOptions, callbackPromises;
        return _regeneratorRuntime().wrap(function _callee10$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                _ref16 = _slicedToArray(_ref15, 6), subscriptionId = _ref16[1], publicationId = _ref16[2], details = _ref16[3], argsList = _ref16[4], argsDict = _ref16[5];
                subscription = this._subscriptionsById.get(subscriptionId);
                if (subscription) {
                  _context10.next = 4;
                  break;
                }
                return _context10.abrupt("return");
              case 4:
                args = argsList;
                kwargs = argsDict; // Check and handle Payload PassThru Mode
                // @see https://wamp-proto.org/wamp_latest_ietf.html#name-payload-passthru-mode
                if (!details.ppt_scheme) {
                  _context10.next = 13;
                  break;
                }
                pptPayload = argsList[0];
                decodedPayload = this._unpackPPTPayload('broker', pptPayload, details);
                if (!decodedPayload.err) {
                  _context10.next = 11;
                  break;
                }
                return _context10.abrupt("return", this._log(decodedPayload.err.message));
              case 11:
                args = decodedPayload.args;
                kwargs = decodedPayload.kwargs;
              case 13:
                callbackOptions = {
                  details: details,
                  argsList: args,
                  argsDict: kwargs
                };
                callbackPromises = subscription.callbacks.map(function (c) {
                  return c(callbackOptions);
                });
                _context10.next = 17;
                return Promise.all(callbackPromises);
              case 17:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee10, this);
      }));
      function _onEventMessage(_x9) {
        return _onEventMessage2.apply(this, arguments);
      }
      return _onEventMessage;
    }()
    /**
     * Handles websocket result message event
     * WAMP SPEC: [RESULT, CALL.Request|id, Details|dict,
     *             YIELD.Arguments|list, YIELD.ArgumentsKw|dict]
     * @param {object} data - decoded event data
     * @private
     */
  }, {
    key: "_onResultMessage",
    value: function () {
      var _onResultMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee11(_ref17) {
        var _ref18, requestId, details, argsList, argsDict, args, kwargs, pptPayload, decodedPayload, callbackOptions;
        return _regeneratorRuntime().wrap(function _callee11$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                _ref18 = _slicedToArray(_ref17, 5), requestId = _ref18[1], details = _ref18[2], argsList = _ref18[3], argsDict = _ref18[4];
                if (this._calls[requestId]) {
                  _context11.next = 3;
                  break;
                }
                return _context11.abrupt("return");
              case 3:
                args = argsList;
                kwargs = argsDict; // Check and handle Payload PassThru Mode
                // @see https://wamp-proto.org/wamp_latest_ietf.html#name-payload-passthru-mode
                if (!details.ppt_scheme) {
                  _context11.next = 17;
                  break;
                }
                pptPayload = argsList[0];
                decodedPayload = this._unpackPPTPayload('dealer', pptPayload, details);
                if (!decodedPayload.err) {
                  _context11.next = 15;
                  break;
                }
                this._log(decodedPayload.err.message);
                this._cache.opStatus = decodedPayload.err;
                _context11.next = 13;
                return this._calls[requestId].onError(new Errors.CallError({
                  details: details,
                  error: 'wamp.error.invocation_exception',
                  argsList: [decodedPayload.err.message],
                  argsDict: null
                }));
              case 13:
                delete this._calls[requestId];
                return _context11.abrupt("return");
              case 15:
                args = decodedPayload.args;
                kwargs = decodedPayload.kwargs;
              case 17:
                callbackOptions = {
                  details: details,
                  argsList: args,
                  argsDict: kwargs
                };
                if (!details.progress) {
                  _context11.next = 23;
                  break;
                }
                _context11.next = 21;
                return this._calls[requestId].onProgress(callbackOptions);
              case 21:
                _context11.next = 26;
                break;
              case 23:
                _context11.next = 25;
                return this._calls[requestId].onSuccess(callbackOptions);
              case 25:
                delete this._calls[requestId];
              case 26:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee11, this);
      }));
      function _onResultMessage(_x10) {
        return _onResultMessage2.apply(this, arguments);
      }
      return _onResultMessage;
    }()
    /**
     * Handles websocket registered message event
     * WAMP SPEC: [REGISTERED, REGISTER.Request|id, Registration|id]
     * @param {Array} [, requestId, registrationId] - decoded event data array
     * @private
     */
  }, {
    key: "_onRegisteredMessage",
    value: function () {
      var _onRegisteredMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee12(_ref19) {
        var _ref20, requestId, registrationId, _this$_requests$reque6, topic, callbacks;
        return _regeneratorRuntime().wrap(function _callee12$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                _ref20 = _slicedToArray(_ref19, 3), requestId = _ref20[1], registrationId = _ref20[2];
                if (this._requests[requestId]) {
                  _context12.next = 3;
                  break;
                }
                return _context12.abrupt("return");
              case 3:
                _this$_requests$reque6 = this._requests[requestId], topic = _this$_requests$reque6.topic, callbacks = _this$_requests$reque6.callbacks;
                this._rpcRegs[registrationId] = {
                  id: registrationId,
                  callbacks: [callbacks.rpc]
                };
                this._rpcRegs[topic] = this._rpcRegs[registrationId];
                this._rpcNames.add(topic);
                if (!(callbacks !== null && callbacks !== void 0 && callbacks.onSuccess)) {
                  _context12.next = 10;
                  break;
                }
                _context12.next = 10;
                return callbacks.onSuccess({
                  topic: topic,
                  requestId: requestId,
                  registrationId: registrationId
                });
              case 10:
                delete this._requests[requestId];
              case 11:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee12, this);
      }));
      function _onRegisteredMessage(_x11) {
        return _onRegisteredMessage2.apply(this, arguments);
      }
      return _onRegisteredMessage;
    }()
    /**
     * Handles websocket unregistered message event
     * WAMP SPEC: [UNREGISTERED, UNREGISTER.Request|id]
     * @param {Array} [, requestId] - decoded event data array
     * @private
     */
  }, {
    key: "_onUnregisteredMessage",
    value: function () {
      var _onUnregisteredMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee13(_ref21) {
        var _ref22, requestId, _this$_requests$reque7, topic, callbacks;
        return _regeneratorRuntime().wrap(function _callee13$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                _ref22 = _slicedToArray(_ref21, 2), requestId = _ref22[1];
                if (this._requests[requestId]) {
                  _context13.next = 3;
                  break;
                }
                return _context13.abrupt("return");
              case 3:
                _this$_requests$reque7 = this._requests[requestId], topic = _this$_requests$reque7.topic, callbacks = _this$_requests$reque7.callbacks;
                delete this._rpcRegs[this._rpcRegs[topic].id];
                delete this._rpcRegs[topic];
                if (this._rpcNames.has(topic)) {
                  this._rpcNames["delete"](topic);
                }
                if (!(callbacks !== null && callbacks !== void 0 && callbacks.onSuccess)) {
                  _context13.next = 10;
                  break;
                }
                _context13.next = 10;
                return callbacks.onSuccess({
                  topic: topic,
                  requestId: requestId
                });
              case 10:
                delete this._requests[requestId];
              case 11:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee13, this);
      }));
      function _onUnregisteredMessage(_x12) {
        return _onUnregisteredMessage2.apply(this, arguments);
      }
      return _onUnregisteredMessage;
    }()
    /**
     * Handles websocket invocation message event
     * @param {Array} data - decoded event data array
     * @private
     */
  }, {
    key: "_onInvocationMessage",
    value: function () {
      var _onInvocationMessage2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee14(_ref23) {
        var _this4 = this;
        var _ref24, requestId, registrationId, details, argsList, argsDict, self, handleInvocationError, args, kwargs, pptPayload, decodedPayload, handleInvocationResult, result;
        return _regeneratorRuntime().wrap(function _callee14$(_context14) {
          while (1) {
            switch (_context14.prev = _context14.next) {
              case 0:
                _ref24 = _slicedToArray(_ref23, 6), requestId = _ref24[1], registrationId = _ref24[2], details = _ref24[3], argsList = _ref24[4], argsDict = _ref24[5];
                self = this;
                handleInvocationError = function handleInvocationError(_ref25) {
                  var error = _ref25.error,
                    details = _ref25.details,
                    argsList = _ref25.argsList,
                    argsDict = _ref25.argsDict;
                  var message = [_constants.WAMP_MSG_SPEC.ERROR, _constants.WAMP_MSG_SPEC.INVOCATION, requestId, details || {}, error || 'wamp.error.invocation_exception'];
                  if (Array.isArray(argsList)) {
                    message.push(argsList);
                  }
                  if (self._isPlainObject(argsDict)) {
                    if (!Array.isArray(argsList)) {
                      message.push([]);
                    }
                    message.push(argsDict);
                  }
                  self._send(message);
                };
                if (this._rpcRegs[registrationId]) {
                  _context14.next = 6;
                  break;
                }
                this._log(_constants.WAMP_ERROR_MSG.NON_EXIST_RPC_INVOCATION);
                return _context14.abrupt("return", handleInvocationError({
                  error: 'wamp.error.no_such_procedure'
                }));
              case 6:
                args = argsList;
                kwargs = argsDict; // Check and handle Payload PassThru Mode
                // @see https://wamp-proto.org/wamp_latest_ietf.html#name-payload-passthru-mode
                if (!(details !== null && details !== void 0 && details.ppt_scheme)) {
                  _context14.next = 18;
                  break;
                }
                pptPayload = argsList[0];
                decodedPayload = this._unpackPPTPayload('dealer', pptPayload, details); // This case should not happen at all, but for safety
                if (!decodedPayload.err) {
                  _context14.next = 16;
                  break;
                }
                this._log(decodedPayload.err.message);
                if (!(decodedPayload.err instanceof Errors.PPTNotSupportedError)) {
                  _context14.next = 15;
                  break;
                }
                return _context14.abrupt("return", this._hardClose('wamp.error.protocol_violation', 'Received INVOCATION in PPT Mode, while Dealer didn\'t announce it'));
              case 15:
                return _context14.abrupt("return", handleInvocationError({
                  details: details,
                  error: 'wamp.error.invocation_exception',
                  argsList: [decodedPayload.err.message]
                }));
              case 16:
                args = decodedPayload.args;
                kwargs = decodedPayload.kwargs;
              case 18:
                handleInvocationResult = function handleInvocationResult(result) {
                  var options = (result === null || result === void 0 ? void 0 : result.options) || {};
                  var ppt_scheme = options.ppt_scheme,
                    ppt_serializer = options.ppt_serializer,
                    ppt_cipher = options.ppt_cipher,
                    ppt_keyid = options.ppt_keyid;

                  // Check and handle Payload PassThru Mode
                  // @see https://wamp-proto.org/wamp_latest_ietf.html#name-payload-passthru-mode
                  if (ppt_scheme && !_this4._checkPPTOptions('dealer', options)) {
                    if (_this4._cache.opStatus.error instanceof Errors.PPTNotSupportedError) {
                      // This case should not happen at all, but for safety
                      return _this4._hardClose('wamp.error.protocol_violation', 'Trying to send YIELD in PPT Mode, while Dealer didn\'t announce it');
                    }
                    return handleInvocationError({
                      details: options,
                      error: 'wamp.error.invalid_option',
                      argsList: [_this4._cache.opStatus.error.message]
                    });
                  }
                  var _ref26 = result ? _this4._packPPTPayload(result, options) : {},
                    err = _ref26.err,
                    payloadItems = _ref26.payloadItems;
                  if (err) {
                    return handleInvocationError({
                      details: options,
                      error: 'wamp.error.invocation_exception',
                      argsList: [_this4._cache.opStatus.error.message]
                    });
                  }
                  var messageOptions = _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, options), ppt_scheme ? {
                    ppt_scheme: ppt_scheme
                  } : {}), ppt_serializer ? {
                    ppt_serializer: ppt_serializer
                  } : {}), ppt_cipher ? {
                    ppt_cipher: ppt_cipher
                  } : {}), ppt_keyid ? {
                    ppt_keyid: ppt_keyid
                  } : {});
                  self._send([_constants.WAMP_MSG_SPEC.YIELD, requestId, messageOptions].concat(_toConsumableArray(payloadItems || [])));
                };
                _context14.prev = 19;
                _context14.next = 22;
                return this._rpcRegs[registrationId].callbacks[0]({
                  details: details,
                  argsList: args,
                  argsDict: kwargs,
                  result_handler: handleInvocationResult,
                  error_handler: handleInvocationError
                });
              case 22:
                result = _context14.sent;
                handleInvocationResult(result);
                _context14.next = 29;
                break;
              case 26:
                _context14.prev = 26;
                _context14.t0 = _context14["catch"](19);
                handleInvocationError(_context14.t0);
              case 29:
              case "end":
                return _context14.stop();
            }
          }
        }, _callee14, this, [[19, 26]]);
      }));
      function _onInvocationMessage(_x13) {
        return _onInvocationMessage2.apply(this, arguments);
      }
      return _onInvocationMessage;
    }()
    /**
     * Internal websocket on error callback
     * @param {object} error
     * @private
     */
  }, {
    key: "_wsOnError",
    value: function _wsOnError(error) {
      this._log('websocket error');
      var websocketError = new Errors.WebsocketError(error);
      if (this._cache.connectPromise) {
        this._cache.connectPromise.onError(websocketError);
        this._cache.connectPromise = null;
      }
      if (this._options.onError) {
        this._options.onError(websocketError);
      }
    }

    /**
     * Reconnect to server in case of websocket error
     * @private
     */
  }, {
    key: "_wsReconnect",
    value: function _wsReconnect() {
      this._log('websocket reconnecting...');
      if (this._options.onReconnect) {
        this._options.onReconnect();
      }
      this._cache.reconnectingAttempts++;
      this._ws = (0, _utils.getWebSocket)({
        url: this._url,
        protocols: this._protocols,
        options: this._options
      });
      this._initWsCallbacks();
    }

    /**
     * Resubscribe to topics in case of communication error
     * @private
     */
  }, {
    key: "_renewSubscriptions",
    value: function _renewSubscriptions() {
      var _this5 = this;
      var i;
      var subs = new Map(this._subscriptionsById);
      this._subscriptionsById.clear();
      this._subscriptionsByKey.clear();
      subs.forEach(function (sub) {
        i = sub.callbacks.length;
        while (i--) {
          _this5.subscribe(sub.topic, sub.callbacks[i], sub.advancedOptions);
        }
      });
    }

    /**
     * Reregister RPCs in case of communication error
     * @private
     */
  }, {
    key: "_renewRegistrations",
    value: function _renewRegistrations() {
      var rpcs = this._rpcRegs,
        rn = this._rpcNames;
      this._rpcRegs = {};
      this._rpcNames = new Set();
      var _iterator = _createForOfIteratorHelper(rn),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var rpcName = _step.value;
          this.register(rpcName, rpcs[rpcName].callbacks[0]);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }

    /**
     * Generate a unique key for combination of topic and options
     *
     * This is needed to allow subscriptions to the same topic URI but with different options
     *
     * @param {string} topic
     * @param {object} options
     * @private
     */
  }, {
    key: "_getSubscriptionKey",
    value: function _getSubscriptionKey(topic, options) {
      return "".concat(topic, "-").concat(JSON.stringify(options));
    }

    /*************************************************************************
     * Wampy public API
     *************************************************************************/

    /**
     * @deprecated since version 7.0.1
     *
     * Get or set Wampy options
     *
     * To get options - call without parameters
     * To set options - pass hash-table with options values
     *
     * @param {object} [newOptions]
     * @returns {*}
     */
  }, {
    key: "options",
    value: function options(newOptions) {
      console.warn('Wampy.options() is deprecated, please use Wampy.getOptions() or Wampy.setOptions() instead');
      if (typeof newOptions === 'undefined') {
        return this._options;
      } else if (this._isPlainObject(newOptions)) {
        this._options = _objectSpread(_objectSpread({}, this._options), newOptions);
        return this;
      }
    }

    /**
     * Wampy options getter
     *
     * @returns {object}
     */
  }, {
    key: "getOptions",
    value: function getOptions() {
      return this._options;
    }

    /**
     * Wampy options setter
     *
     * @param {object} newOptions
     * @returns {*}
     */
  }, {
    key: "setOptions",
    value: function setOptions(newOptions) {
      if (this._isPlainObject(newOptions)) {
        this._options = _objectSpread(_objectSpread({}, this._options), newOptions);
        return this;
      }
    }

    /**
     * Get the status of last operation
     *
     * @returns {object} with 3 fields: code, error, reqId
     *      code: 0 - if operation was successful
     *      code > 0 - if error occurred
     *      error: error instance containing details
     *      reqId: last successfully sent request ID
     */
  }, {
    key: "getOpStatus",
    value: function getOpStatus() {
      return this._cache.opStatus;
    }

    /**
     * Get the WAMP Session ID
     *
     * @returns {string} Session ID
     */
  }, {
    key: "getSessionId",
    value: function getSessionId() {
      return this._cache.sessionId;
    }

    /**
     * Connect to server
     * @param {string} [url] New url (optional)
     * @returns {Promise}
     */
  }, {
    key: "connect",
    value: function () {
      var _connect = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee15(url) {
        var noRealmError, numberOfAuthOptions, noCRACallbackOrIdError, noWsOrUrlError, defer;
        return _regeneratorRuntime().wrap(function _callee15$(_context15) {
          while (1) {
            switch (_context15.prev = _context15.next) {
              case 0:
                if (url) {
                  this._url = url;
                }
                if (this._options.realm) {
                  _context15.next = 5;
                  break;
                }
                noRealmError = new Errors.NoRealmError();
                this._fillOpStatusByError(noRealmError);
                throw noRealmError;
              case 5:
                numberOfAuthOptions = (this._options.authid ? 1 : 0) + (Array.isArray(this._options.authmethods) && this._options.authmethods.length ? 1 : 0) + (typeof this._options.onChallenge === 'function' || Object.keys(this._options.authPlugins).length ? 1 : 0);
                if (!(numberOfAuthOptions > 0 && numberOfAuthOptions < 3)) {
                  _context15.next = 10;
                  break;
                }
                noCRACallbackOrIdError = new Errors.NoCRACallbackOrIdError();
                this._fillOpStatusByError(noCRACallbackOrIdError);
                throw noCRACallbackOrIdError;
              case 10:
                this._setWsProtocols();
                this._ws = (0, _utils.getWebSocket)({
                  url: this._url,
                  protocols: this._protocols,
                  options: this._options
                });
                if (this._ws) {
                  _context15.next = 16;
                  break;
                }
                noWsOrUrlError = new Errors.NoWsOrUrlError();
                this._fillOpStatusByError(noWsOrUrlError);
                throw noWsOrUrlError;
              case 16:
                this._initWsCallbacks();
                defer = (0, _utils.getNewPromise)();
                this._cache.connectPromise = defer;
                return _context15.abrupt("return", defer.promise);
              case 20:
              case "end":
                return _context15.stop();
            }
          }
        }, _callee15, this);
      }));
      function connect(_x14) {
        return _connect.apply(this, arguments);
      }
      return connect;
    }()
    /**
     * Disconnect from server
     * @returns {Promise}
     */
  }, {
    key: "disconnect",
    value: function () {
      var _disconnect = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee16() {
        var defer;
        return _regeneratorRuntime().wrap(function _callee16$(_context16) {
          while (1) {
            switch (_context16.prev = _context16.next) {
              case 0:
                if (!this._cache.sessionId) {
                  _context16.next = 9;
                  break;
                }
                defer = (0, _utils.getNewPromise)();
                this._cache.opStatus = _constants.SUCCESS;
                this._cache.closePromise = defer;
                // need to send goodbye message to server
                this._cache.isSayingGoodbye = true;
                this._send([_constants.WAMP_MSG_SPEC.GOODBYE, {}, 'wamp.close.system_shutdown']);
                return _context16.abrupt("return", defer.promise);
              case 9:
                if (this._ws) {
                  this._ws.close();
                }
              case 10:
                return _context16.abrupt("return", true);
              case 11:
              case "end":
                return _context16.stop();
            }
          }
        }, _callee16, this);
      }));
      function disconnect() {
        return _disconnect.apply(this, arguments);
      }
      return disconnect;
    }()
    /**
     * Abort WAMP session establishment
     *
     * @returns {Wampy}
     */
  }, {
    key: "abort",
    value: function abort() {
      if (!this._cache.sessionId && this._ws.readyState === 1) {
        this._send([_constants.WAMP_MSG_SPEC.ABORT, {}, 'wamp.error.abort']);
        this._cache.sessionId = null;
      }
      this._ws.close();
      this._cache.opStatus = _constants.SUCCESS;
      return this;
    }

    /**
     * Subscribe to a topic on a broker
     *
     * @param {string} topic - a URI to subscribe to
     * @param {function} onEvent - received event callback
     * @param {object} [advancedOptions] - optional parameter. Must include any or all of the options:
     *                          { match: string matching policy ("prefix"|"wildcard") }
     *
     * @returns {Promise}
     */
  }, {
    key: "subscribe",
    value: function () {
      var _subscribe = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee17(topic, onEvent, advancedOptions) {
        var isAdvancedOptionsAnObject, invalidParamError, match, patternBased, _invalidParamError, noCallbackError, subscriptionKey, subscription, reqId, callbacks;
        return _regeneratorRuntime().wrap(function _callee17$(_context17) {
          while (1) {
            switch (_context17.prev = _context17.next) {
              case 0:
                isAdvancedOptionsAnObject = this._isPlainObject(advancedOptions);
                if (!(!isAdvancedOptionsAnObject && typeof advancedOptions !== 'undefined')) {
                  _context17.next = 5;
                  break;
                }
                invalidParamError = new Errors.InvalidParamError('advancedOptions');
                this._fillOpStatusByError(invalidParamError);
                throw invalidParamError;
              case 5:
                patternBased = false;
                if (!(isAdvancedOptionsAnObject && Object.prototype.hasOwnProperty.call(advancedOptions, 'match'))) {
                  _context17.next = 13;
                  break;
                }
                if (['prefix', 'wildcard'].includes(advancedOptions.match)) {
                  _context17.next = 11;
                  break;
                }
                _invalidParamError = new Errors.InvalidParamError('match');
                this._fillOpStatusByError(_invalidParamError);
                throw _invalidParamError;
              case 11:
                match = advancedOptions.match;
                patternBased = true;
              case 13:
                if (this._preReqChecks({
                  topic: topic,
                  patternBased: patternBased,
                  allowWAMP: true
                }, 'broker')) {
                  _context17.next = 15;
                  break;
                }
                throw this._cache.opStatus.error;
              case 15:
                if (!(typeof onEvent !== 'function')) {
                  _context17.next = 19;
                  break;
                }
                noCallbackError = new Errors.NoCallbackError();
                this._fillOpStatusByError(noCallbackError);
                throw noCallbackError;
              case 19:
                subscriptionKey = this._getSubscriptionKey(topic, advancedOptions);
                subscription = this._subscriptionsByKey.get(subscriptionKey);
                if (!(subscription && subscription.callbacks.length > 0)) {
                  _context17.next = 24;
                  break;
                }
                if (!subscription.callbacks.includes(onEvent)) {
                  subscription.callbacks.push(onEvent);
                }
                return _context17.abrupt("return", {
                  topic: topic,
                  requestId: 0,
                  subscriptionId: subscription.id,
                  subscriptionKey: subscriptionKey
                });
              case 24:
                reqId = this._getReqId();
                callbacks = (0, _utils.getNewPromise)();
                callbacks.onEvent = onEvent;
                this._requests[reqId] = {
                  topic: topic,
                  callbacks: callbacks,
                  advancedOptions: advancedOptions
                };

                // WAMP SPEC: [SUBSCRIBE, Request|id, Options|dict, Topic|uri]
                this._send([_constants.WAMP_MSG_SPEC.SUBSCRIBE, reqId, {
                  match: match
                }, topic]);
                this._cache.opStatus = _objectSpread(_objectSpread({}, _constants.SUCCESS), {}, {
                  reqId: reqId || 0
                });
                return _context17.abrupt("return", callbacks.promise);
              case 31:
              case "end":
                return _context17.stop();
            }
          }
        }, _callee17, this);
      }));
      function subscribe(_x15, _x16, _x17) {
        return _subscribe.apply(this, arguments);
      }
      return subscribe;
    }()
    /**
     * Unsubscribe from topic
     * @param {string|number} subscriptionIdOrKey Subscription ID or Key, received during .subscribe()
     * @param {function} [onEvent] - received event callback to remove (optional). If not provided -
     *                               all callbacks will be removed and unsubscribed on the server
     * @returns {Promise}
     */
  }, {
    key: "unsubscribe",
    value: function () {
      var _unsubscribe = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee18(subscriptionIdOrKey, onEvent) {
        var subscription, nonExistUnsubscribeError, isThereOtherCallbackForThisTopic, reqId;
        return _regeneratorRuntime().wrap(function _callee18$(_context18) {
          while (1) {
            switch (_context18.prev = _context18.next) {
              case 0:
                if (this._preReqChecks(null, 'broker')) {
                  _context18.next = 2;
                  break;
                }
                throw this._cache.opStatus.error;
              case 2:
                subscription = this._subscriptionsById.get(subscriptionIdOrKey) || this._subscriptionsByKey.get(subscriptionIdOrKey);
                if (subscription) {
                  _context18.next = 7;
                  break;
                }
                nonExistUnsubscribeError = new Errors.NonExistUnsubscribeError();
                this._fillOpStatusByError(nonExistUnsubscribeError);
                throw nonExistUnsubscribeError;
              case 7:
                subscription.callbacks = typeof onEvent === 'function' ? subscription.callbacks.filter(function (callback) {
                  return callback !== onEvent;
                }) : [];
                isThereOtherCallbackForThisTopic = subscription.callbacks.length > 0;
                if (!isThereOtherCallbackForThisTopic) {
                  _context18.next = 12;
                  break;
                }
                this._cache.opStatus = _constants.SUCCESS;
                return _context18.abrupt("return", true);
              case 12:
                reqId = this._getReqId();
                this._requests[reqId] = {
                  topic: subscription.topic,
                  callbacks: (0, _utils.getNewPromise)()
                };

                // WAMP_SPEC: [UNSUBSCRIBE, Request|id, SUBSCRIBED.Subscription|id]
                this._send([_constants.WAMP_MSG_SPEC.UNSUBSCRIBE, reqId, subscription.id]);
                this._cache.opStatus = _objectSpread(_objectSpread({}, _constants.SUCCESS), {}, {
                  reqId: reqId
                });
                return _context18.abrupt("return", this._requests[reqId].callbacks.promise);
              case 17:
              case "end":
                return _context18.stop();
            }
          }
        }, _callee18, this);
      }));
      function unsubscribe(_x18, _x19) {
        return _unsubscribe.apply(this, arguments);
      }
      return unsubscribe;
    }()
    /**
     * Publish an event to the topic
     * @param {string} topic
     * @param {string|number|Array|object} [payload] - can be either a value of any type or null or even omitted.
     *                          Also, it is possible to pass array and object-like data simultaneously.
     *                          In this case pass a hash-table with next attributes:
     *                          {
     *                             argsList: array payload (may be omitted)
     *                             argsDict: object payload (may be omitted)
     *                          }
     * @param {object} [advancedOptions] - optional parameter. Must include any or all of the options:
     *                          { exclude: integer|array WAMP session id(s) that won't receive a published event,
     *                                      even though they may be subscribed
     *                            exclude_authid: string|array Authentication id(s) that won't receive
     *                                      a published event, even though they may be subscribed
     *                            exclude_authrole: string|array Authentication role(s) that won't receive
     *                                      a published event, even though they may be subscribed
     *                            eligible: integer|array WAMP session id(s) that are allowed
     *                                      to receive a published event
     *                            eligible_authid: string|array Authentication id(s) that are allowed
     *                                      to receive a published event
     *                            eligible_authrole: string|array Authentication role(s) that are allowed
     *                                      to receive a published event
     *                            exclude_me: bool flag of receiving publishing event by initiator
     *                            disclose_me: bool flag of disclosure of publisher identity (its WAMP session ID)
     *                                      to receivers of a published event
     *                            ppt_scheme: string Identifies the Payload Schema
     *                            ppt_serializer: string Specifies what serializer was used to encode the payload
     *                            ppt_cipher: string Specifies the cryptographic algorithm that was used to encrypt
     *                                      the payload
     *                            ppt_keyid: string Contains the encryption key id that was used to encrypt the payload
     *                          }
     * @returns {Promise}
     */
  }, {
    key: "publish",
    value: function () {
      var _publish = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee19(topic, payload, advancedOptions) {
        var isAdvancedOptionsAnObject, error, messageOptions, _optionsConvertHelper, invalidParamError, _ref27, ppt_scheme, ppt_serializer, ppt_cipher, ppt_keyid, exclude_me, disclose_me, _ref28, err, payloadItems, reqId;
        return _regeneratorRuntime().wrap(function _callee19$(_context19) {
          while (1) {
            switch (_context19.prev = _context19.next) {
              case 0:
                if (this._preReqChecks({
                  topic: topic,
                  patternBased: false,
                  allowWAMP: false
                }, 'broker')) {
                  _context19.next = 2;
                  break;
                }
                throw this._cache.opStatus.error;
              case 2:
                isAdvancedOptionsAnObject = this._isPlainObject(advancedOptions);
                if (!(advancedOptions && !isAdvancedOptionsAnObject)) {
                  _context19.next = 7;
                  break;
                }
                error = new Errors.InvalidParamError('advancedOptions');
                this._fillOpStatusByError(error);
                throw error;
              case 7:
                messageOptions = {};
                _optionsConvertHelper = function _optionsConvertHelper(option, sourceType) {
                  if (advancedOptions[option]) {
                    if (Array.isArray(advancedOptions[option]) && advancedOptions[option].length) {
                      messageOptions[option] = advancedOptions[option];
                    } else if (_typeof(advancedOptions[option]) === sourceType) {
                      messageOptions[option] = [advancedOptions[option]];
                    } else {
                      return false;
                    }
                  }
                  return true;
                };
                if (!(isAdvancedOptionsAnObject && (!_optionsConvertHelper('exclude', 'number') || !_optionsConvertHelper('exclude_authid', 'string') || !_optionsConvertHelper('exclude_authrole', 'string') || !_optionsConvertHelper('eligible', 'number') || !_optionsConvertHelper('eligible_authid', 'string') || !_optionsConvertHelper('eligible_authrole', 'string')))) {
                  _context19.next = 13;
                  break;
                }
                invalidParamError = new Errors.InvalidParamError('advancedOptions');
                this._fillOpStatusByError(invalidParamError);
                throw invalidParamError;
              case 13:
                _ref27 = advancedOptions || {}, ppt_scheme = _ref27.ppt_scheme, ppt_serializer = _ref27.ppt_serializer, ppt_cipher = _ref27.ppt_cipher, ppt_keyid = _ref27.ppt_keyid, exclude_me = _ref27.exclude_me, disclose_me = _ref27.disclose_me; // Check and handle Payload PassThru Mode
                // @see https://wamp-proto.org/wamp_latest_ietf.html#name-payload-passthru-mode
                if (!(ppt_scheme && !this._checkPPTOptions('broker', advancedOptions))) {
                  _context19.next = 16;
                  break;
                }
                throw this._cache.opStatus.error;
              case 16:
                messageOptions = _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({
                  acknowledge: true
                }, messageOptions), ppt_scheme ? {
                  ppt_scheme: ppt_scheme
                } : {}), ppt_scheme ? {
                  ppt_scheme: ppt_scheme
                } : {}), ppt_serializer ? {
                  ppt_serializer: ppt_serializer
                } : {}), ppt_cipher ? {
                  ppt_cipher: ppt_cipher
                } : {}), ppt_keyid ? {
                  ppt_keyid: ppt_keyid
                } : {}), exclude_me ? {
                  exclude_me: exclude_me
                } : {}), disclose_me ? {
                  disclose_me: disclose_me
                } : {});
                _ref28 = payload ? this._packPPTPayload(payload, messageOptions) : {}, err = _ref28.err, payloadItems = _ref28.payloadItems;
                reqId = this._getReqId();
                if (!err) {
                  _context19.next = 21;
                  break;
                }
                throw this._cache.opStatus.error;
              case 21:
                this._requests[reqId] = {
                  topic: topic,
                  callbacks: (0, _utils.getNewPromise)()
                };
                this._cache.opStatus = _objectSpread(_objectSpread({}, _constants.SUCCESS), {}, {
                  reqId: reqId
                });
                this._send([_constants.WAMP_MSG_SPEC.PUBLISH, reqId, messageOptions, topic].concat(_toConsumableArray(payloadItems || [])));
                return _context19.abrupt("return", this._requests[reqId].callbacks.promise);
              case 25:
              case "end":
                return _context19.stop();
            }
          }
        }, _callee19, this);
      }));
      function publish(_x20, _x21, _x22) {
        return _publish.apply(this, arguments);
      }
      return publish;
    }()
    /**
     * Remote Procedure Call
     * @param {string} topic - a topic URI to be called
     * @param {string|number|Array|object} [payload] - can be either a value of any type or null. Also, it
     *                          is possible to pass array and object-like data simultaneously.
     *                          In this case pass a hash-table with next attributes:
     *                          {
     *                             argsList: array payload (may be omitted)
     *                             argsDict: object payload (may be omitted)
     *                          }
     * @param {object} [advancedOptions] - optional parameter. Must include any or all of the options:
     *                          { disclose_me:      bool flag of disclosure of Caller identity (WAMP session ID)
     *                                              to endpoints of a routed call
     *                            progress_callback: function for handling progressive call results
     *                            timeout:          integer timeout (in ms) for the call to finish
     *                            ppt_scheme: string Identifies the Payload Schema
     *                            ppt_serializer: string Specifies what serializer was used to encode the payload
     *                            ppt_cipher: string Specifies the cryptographic algorithm that was used to encrypt
     *                                the payload
     *                            ppt_keyid: string Contains the encryption key id that was used to encrypt the payload
     *                          }
     * @returns {Promise}
     */
  }, {
    key: "call",
    value: function () {
      var _call = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee20(topic, payload, advancedOptions) {
        var invalidParamError, _ref29, timeout, progress_callback, disclose_me, isTimeoutInvalid, isProgressCallbackInvalid, paramName, _ref30, ppt_scheme, ppt_serializer, ppt_cipher, ppt_keyid, reqId, messageOptions, _ref31, err, payloadItems;
        return _regeneratorRuntime().wrap(function _callee20$(_context20) {
          while (1) {
            switch (_context20.prev = _context20.next) {
              case 0:
                if (this._preReqChecks({
                  topic: topic,
                  patternBased: false,
                  allowWAMP: true
                }, 'dealer')) {
                  _context20.next = 2;
                  break;
                }
                throw this._cache.opStatus.error;
              case 2:
                if (!(advancedOptions && !this._isPlainObject(advancedOptions))) {
                  _context20.next = 6;
                  break;
                }
                invalidParamError = new Errors.InvalidParamError('advancedOptions');
                this._fillOpStatusByError(invalidParamError);
                throw invalidParamError;
              case 6:
                _ref29 = advancedOptions || {}, timeout = _ref29.timeout, progress_callback = _ref29.progress_callback, disclose_me = _ref29.disclose_me;
                isTimeoutInvalid = timeout && typeof timeout !== 'number';
                isProgressCallbackInvalid = progress_callback && typeof progress_callback !== 'function';
                if (!(isTimeoutInvalid || isProgressCallbackInvalid)) {
                  _context20.next = 14;
                  break;
                }
                paramName = isTimeoutInvalid ? 'timeout' : 'progress_callback';
                invalidParamError = new Errors.InvalidParamError(paramName);
                this._fillOpStatusByError(invalidParamError);
                throw invalidParamError;
              case 14:
                _ref30 = advancedOptions || {}, ppt_scheme = _ref30.ppt_scheme, ppt_serializer = _ref30.ppt_serializer, ppt_cipher = _ref30.ppt_cipher, ppt_keyid = _ref30.ppt_keyid; // Check and handle Payload PassThru Mode
                // @see https://wamp-proto.org/wamp_latest_ietf.html#name-payload-passthru-mode
                if (!(ppt_scheme && !this._checkPPTOptions('dealer', advancedOptions))) {
                  _context20.next = 17;
                  break;
                }
                throw this._cache.opStatus.error;
              case 17:
                do {
                  reqId = this._getReqId();
                } while (reqId in this._calls);
                messageOptions = _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, progress_callback ? {
                  receive_progress: true
                } : {}), disclose_me ? {
                  disclose_me: true
                } : {}), timeout ? {
                  timeout: timeout
                } : {}), ppt_scheme ? {
                  ppt_scheme: ppt_scheme
                } : {}), ppt_serializer ? {
                  ppt_serializer: ppt_serializer
                } : {}), ppt_cipher ? {
                  ppt_cipher: ppt_cipher
                } : {}), ppt_keyid ? {
                  ppt_keyid: ppt_keyid
                } : {});
                _ref31 = payload ? this._packPPTPayload(payload, messageOptions) : {}, err = _ref31.err, payloadItems = _ref31.payloadItems;
                if (!err) {
                  _context20.next = 22;
                  break;
                }
                throw this._cache.opStatus.error;
              case 22:
                // WAMP SPEC: [CALL, Request|id, Options|dict, Procedure|uri, (Arguments|list, ArgumentsKw|dict)]
                this._send([_constants.WAMP_MSG_SPEC.CALL, reqId, messageOptions, topic].concat(_toConsumableArray(payloadItems || [])));
                this._cache.opStatus = _objectSpread(_objectSpread({}, _constants.SUCCESS), {}, {
                  reqId: reqId
                });
                this._calls[reqId] = (0, _utils.getNewPromise)();
                if (progress_callback) {
                  this._calls[reqId].onProgress = progress_callback;
                }
                return _context20.abrupt("return", this._calls[reqId].promise);
              case 27:
              case "end":
                return _context20.stop();
            }
          }
        }, _callee20, this);
      }));
      function call(_x23, _x24, _x25) {
        return _call.apply(this, arguments);
      }
      return call;
    }()
    /**
     * RPC invocation cancelling
     *
     * @param {int} reqId RPC call request ID
     * @param {object} [advancedOptions] - optional parameter. Must include any or all of the options:
     *                          { mode: string|one of the possible modes:
     *                                  "skip" | "kill" | "killnowait". Skip is default.
     *                          }
     *
     * @returns {Boolean}
     */
  }, {
    key: "cancel",
    value: function cancel(reqId, advancedOptions) {
      if (!this._preReqChecks(null, 'dealer') || !this._checkRouterFeature('dealer', 'call_canceling')) {
        throw this._cache.opStatus.error;
      }
      if (!reqId || !this._calls[reqId]) {
        var nonExistRPCReqIdError = new Errors.NonExistRPCReqIdError();
        this._fillOpStatusByError(nonExistRPCReqIdError);
        throw nonExistRPCReqIdError;
      }
      if (!this._isPlainObject(advancedOptions) && typeof advancedOptions !== 'undefined') {
        var invalidParamError = new Errors.InvalidParamError('advancedOptions');
        this._fillOpStatusByError(invalidParamError);
        throw invalidParamError;
      }
      var mode;
      if (this._isPlainObject(advancedOptions) && Object.hasOwnProperty.call(advancedOptions, 'mode')) {
        if (!['skip', 'kill', 'killnowait'].includes(advancedOptions.mode)) {
          var error = new Errors.InvalidParamError('mode');
          this._fillOpStatusByError(error);
          throw error;
        }
        mode = advancedOptions.mode;
      }

      // WAMP SPEC: [CANCEL, CALL.Request|id, Options|dict]
      this._send([_constants.WAMP_MSG_SPEC.CANCEL, reqId, {
        mode: mode
      }]);
      this._cache.opStatus = _objectSpread(_objectSpread({}, _constants.SUCCESS), {}, {
        reqId: reqId
      });
      return true;
    }

    /**
     * RPC registration for invocation
     * @param {string} topic
     * @param {function} rpc - rpc that will receive invocations
     * @param {object} [advancedOptions] - optional parameter. Must include any or all of the options:
     *                          {
     *                              match: string matching policy ("prefix"|"wildcard")
     *                              invoke: string invocation policy ("single"|"roundrobin"|"random"|"first"|"last")
     *                          }
     * @returns {Promise}
     */
  }, {
    key: "register",
    value: function () {
      var _register = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee21(topic, rpc, advancedOptions) {
        var _this$_rpcRegs$topic, _this$_rpcRegs$topic$;
        var rpcAlreadyRegisteredError, noCallbackError, invalidParamError, _ref32, match, invoke, isMatchInvalid, isInvokeInvalid, parameter, reqId, callbacks, options;
        return _regeneratorRuntime().wrap(function _callee21$(_context21) {
          while (1) {
            switch (_context21.prev = _context21.next) {
              case 0:
                if (!((_this$_rpcRegs$topic = this._rpcRegs[topic]) !== null && _this$_rpcRegs$topic !== void 0 && (_this$_rpcRegs$topic$ = _this$_rpcRegs$topic.callbacks) !== null && _this$_rpcRegs$topic$ !== void 0 && _this$_rpcRegs$topic$.length)) {
                  _context21.next = 4;
                  break;
                }
                rpcAlreadyRegisteredError = new Errors.RPCAlreadyRegisteredError();
                this._fillOpStatusByError(rpcAlreadyRegisteredError);
                throw rpcAlreadyRegisteredError;
              case 4:
                if (!(typeof rpc !== 'function')) {
                  _context21.next = 8;
                  break;
                }
                noCallbackError = new Errors.NoCallbackError();
                this._fillOpStatusByError(noCallbackError);
                throw noCallbackError;
              case 8:
                if (!(advancedOptions && !this._isPlainObject(advancedOptions))) {
                  _context21.next = 12;
                  break;
                }
                invalidParamError = new Errors.InvalidParamError('advancedOptions');
                this._fillOpStatusByError(invalidParamError);
                throw invalidParamError;
              case 12:
                _ref32 = advancedOptions || {}, match = _ref32.match, invoke = _ref32.invoke;
                isMatchInvalid = match && !['prefix', 'wildcard'].includes(match);
                isInvokeInvalid = invoke && !['single', 'roundrobin', 'random', 'first', 'last'].includes(invoke);
                if (!(isMatchInvalid || isInvokeInvalid)) {
                  _context21.next = 20;
                  break;
                }
                parameter = isMatchInvalid ? 'match' : 'invoke';
                invalidParamError = new Errors.InvalidParamError(parameter);
                this._fillOpStatusByError(invalidParamError);
                throw invalidParamError;
              case 20:
                if (this._preReqChecks({
                  topic: topic,
                  patternBased: Boolean(match),
                  allowWAMP: false
                }, 'dealer')) {
                  _context21.next = 22;
                  break;
                }
                throw this._cache.opStatus.error;
              case 22:
                reqId = this._getReqId();
                callbacks = (0, _utils.getNewPromise)();
                options = _objectSpread(_objectSpread({}, match ? {
                  match: match
                } : {}), invoke ? {
                  invoke: invoke
                } : {});
                if (rpc) {
                  callbacks.rpc = rpc;
                }
                this._requests[reqId] = {
                  topic: topic,
                  callbacks: callbacks
                };

                // WAMP SPEC: [REGISTER, Request|id, Options|dict, Procedure|uri]
                this._send([_constants.WAMP_MSG_SPEC.REGISTER, reqId, options, topic]);
                this._cache.opStatus = _objectSpread(_objectSpread({}, _constants.SUCCESS), {}, {
                  reqId: reqId
                });
                return _context21.abrupt("return", callbacks.promise);
              case 30:
              case "end":
                return _context21.stop();
            }
          }
        }, _callee21, this);
      }));
      function register(_x26, _x27, _x28) {
        return _register.apply(this, arguments);
      }
      return register;
    }()
    /**
     * RPC unregistration for invocation
     * @param {string} topic - a topic URI to unregister
     * @returns {Promise}
     */
  }, {
    key: "unregister",
    value: function () {
      var _unregister = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee22(topic) {
        var nonExistRpcUnregistrationError, reqId, callbacks;
        return _regeneratorRuntime().wrap(function _callee22$(_context22) {
          while (1) {
            switch (_context22.prev = _context22.next) {
              case 0:
                if (this._preReqChecks({
                  topic: topic,
                  patternBased: false,
                  allowWAMP: false
                }, 'dealer')) {
                  _context22.next = 2;
                  break;
                }
                throw this._cache.opStatus.error;
              case 2:
                if (this._rpcRegs[topic]) {
                  _context22.next = 6;
                  break;
                }
                nonExistRpcUnregistrationError = new Errors.NonExistRPCUnregistrationError();
                this._fillOpStatusByError(nonExistRpcUnregistrationError);
                throw nonExistRpcUnregistrationError;
              case 6:
                reqId = this._getReqId();
                callbacks = (0, _utils.getNewPromise)();
                this._requests[reqId] = {
                  topic: topic,
                  callbacks: callbacks
                };

                // WAMP SPEC: [UNREGISTER, Request|id, REGISTERED.Registration|id]
                this._send([_constants.WAMP_MSG_SPEC.UNREGISTER, reqId, this._rpcRegs[topic].id]);
                this._cache.opStatus = _objectSpread(_objectSpread({}, _constants.SUCCESS), {}, {
                  reqId: reqId
                });
                return _context22.abrupt("return", callbacks.promise);
              case 12:
              case "end":
                return _context22.stop();
            }
          }
        }, _callee22, this);
      }));
      function unregister(_x29) {
        return _unregister.apply(this, arguments);
      }
      return unregister;
    }()
  }]);
  return Wampy;
}();
exports.Wampy = Wampy;
var _default = Wampy;
exports["default"] = _default;

},{"./constants.js":3,"./errors.js":4,"./serializers/JsonSerializer.js":5,"./utils.js":6}]},{},[2]);
